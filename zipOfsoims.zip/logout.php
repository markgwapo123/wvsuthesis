<?php
session_start();

// Remove all session data
session_unset();
session_destroy();

// Respond OK to JS fetch (no redirect here)
http_response_code(200);
exit();
?>
