<?php
session_start();
require_once __DIR__ . "/db_connect.php";

/* ======================
   ADMIN AUTH CHECK
====================== */
if (($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: index.php?error=Unauthorized");
    exit();
}

/* ======================
   VALIDATE REQUEST ID
====================== */
$request_id = $_GET['request_id'] ?? null;
if (!$request_id) {
    exit("Invalid request ID.");
}

/* ======================
   FETCH REQUEST (LOCKED)
====================== */
$stmt = $conn->prepare("
    SELECT 
        request_id,
        inventory_id,
        qty_requested,
        status
    FROM requests
    WHERE request_id = ?
");
$stmt->bind_param("i", $request_id);
$stmt->execute();
$request = $stmt->get_result()->fetch_assoc();

if (!$request) {
    exit("Request not found.");
}

if ($request['status'] !== 'Pending') {
    exit("This request has already been processed.");
}

$inventory_id = (int)$request['inventory_id'];
$qty_requested = (int)$request['qty_requested'];

/* ======================
   FETCH INVENTORY
====================== */
$stmt = $conn->prepare("
    SELECT quantity
    FROM inventory
    WHERE inventory_id = ?
");
$stmt->bind_param("i", $inventory_id);
$stmt->execute();
$inventory = $stmt->get_result()->fetch_assoc();

if (!$inventory) {
    exit("Inventory item not found.");
}

$current_stock = (int)$inventory['quantity'];

if ($qty_requested > $current_stock) {
    exit("Insufficient stock to approve this request.");
}

/* ======================
   TRANSACTION START
====================== */
$conn->begin_transaction();

try {

    /* Deduct stock */
    $stmt = $conn->prepare("
        UPDATE inventory
        SET quantity = quantity - ?
        WHERE inventory_id = ?
    ");
    $stmt->bind_param("ii", $qty_requested, $inventory_id);
    $stmt->execute();

    /* Update request */
    $stmt = $conn->prepare("
        UPDATE requests
        SET 
            status = 'Approved',
            processed_by_user_id = ?,
            processed_by_name = ?,
            processed_at = NOW()
        WHERE request_id = ?
    ");
    $stmt->bind_param(
        "isi",
        $_SESSION['user_id'],
        $_SESSION['fullname'],
        $request_id
    );
    $stmt->execute();

    $conn->commit();

    header("Location: admin_requests.php?success=Request+Approved");
    exit();

} catch (Exception $e) {

    $conn->rollback();
    exit("Approval failed: " . $e->getMessage());
}
