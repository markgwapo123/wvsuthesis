<?php 
session_start();
require_once __DIR__ . '/db_connect.php';

// Handle barcode generation form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name        = $conn->real_escape_string($_POST['name']);
  $description = $conn->real_escape_string($_POST['description']);
  $category    = $conn->real_escape_string($_POST['category']);
  $quantity    = (int) $_POST['quantity'];
  $expiration  = !empty($_POST['expiration_date']) ? "'" . $conn->real_escape_string($_POST['expiration_date']) . "'" : "NULL";
  $unit        = $conn->real_escape_string($_POST['unit']);
  $condition   = $conn->real_escape_string($_POST['condition_label']);
  $status      = $conn->real_escape_string($_POST['status_label']);
  $location    = $conn->real_escape_string($_POST['location']);
  $department  = $conn->real_escape_string($_POST['department']); // NEW FIELD
  $supplier_id = !empty($_POST['supplier_id']) ? (int) $_POST['supplier_id'] : "NULL";
  $min_stock = isset($_POST['min_stock']) ? (int) $_POST['min_stock'] : 0; // Default to 0 if not set

  $image_path = '';
  if (!empty($_FILES['image']['name'])) {
    $dir = 'uploads/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $file = $dir . basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'], $file);
    $image_path = $conn->real_escape_string($file);
  }

  // Insert item
  $sql = "
    INSERT INTO items
    (name, description, category, quantity, expiration_date, unit,
     condition_label, status_label, min_stock, location, department, supplier_id,
     image_path, created_at, updated_at)
    VALUES
    ('$name', '$description', '$category', $quantity,
     $expiration, '$unit', '$condition', '$status','$min_stock',
     '$location', '$department', $supplier_id, '$image_path', NOW(), NOW())
  ";

  if (!$conn->query($sql)) die('Insert failed: ' . $conn->error);

  $item_id = $conn->insert_id;
  $base = 'ITEM' . str_pad($item_id, 6, '0', STR_PAD_LEFT);
  $conn->query("UPDATE items SET barcode='$base', code='$base' WHERE item_id=$item_id");

  for ($i = 1; $i <= $quantity; $i++) {
    $unique = $base . '-' . str_pad($i, 2, '0', STR_PAD_LEFT);
    $conn->query("INSERT INTO barcodes (item_id, barcode_code) VALUES ($item_id, '$unique')");
  }

  header("Location: generate_barcode.php?success=" . urlencode("Item added successfully! $quantity barcodes generated."));
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Item & Generate Barcodes</title>
<link href="assets\bootstrap-5.3.2-dist\css\bootstrap.css" rel="stylesheet">
<style>
  body {
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #143ab7ff, #143ab7ff);
    margin: 0;
    padding: 0;
    color: #333;
  }

  .main-content {
    max-width: 800px;
    max-height: fit-content;
    margin: 50px auto;
    background: #fff;
    border-radius: 20px;
    padding: 40px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    animation: fadeIn 0.6s ease;
  }

  h1 {
    text-align: center;
    color: #3b3b98;
    margin-bottom: 25px;
  }

  .grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
  }

  input,
  select,
  textarea {
    height: 50px;
    padding: 7px 9px;
    border-radius: 10px;
    border: 1px solid #ccd6f6;
    font-size: 14px;
    background-color: #fafaff;
    transition: all 0.3s ease;
  }

  input:focus,
  select:focus,
  textarea:focus {
    outline: none;
    border-color: #2c69daff;
    box-shadow: 0 0 4px rgba(47, 57, 252, 0.3);
  }

  textarea {
    grid-column: 1 / 3 ;
    resize: vertical;
  }

  .submit-btn {
    grid-column: 1 / 3;
    padding: 12px;
    background-color: #395ffaff;
    color: #fff;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    font-size: 15px;
    transition: background-color 0.3s, transform 0.2s;
  }

  .submit-btn:hover {
    background-color: #180fcaff;
    transform: translateY(-2px);
  }

  .back-btn {
    display: block;
    margin: 25px auto 0;
    background-color: #ff7b9c;
    color: #fff;
    border: none;
    padding: 10px 25px;
    border-radius: 10px;
    font-size: 14px;
    cursor: pointer;
    transition: background 0.3s, transform 0.2s;
  }

  .back-btn:hover {
    background-color: #ff4f7a;
    transform: translateY(-2px);
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
</style>
</head>
<body>

<div class="main-content">
  <h1>📦 Add New Item & Generate Barcodes</h1>

  <form method="POST" enctype="multipart/form-data" class="grid">
    <input name="name" placeholder="Item Name" required>
    <select name="category" required>
      <option disabled selected>Category</option>
      <option>Stationary</option>
      <option>Cleaning</option>
      <option>Tech</option>
      <option>Misc</option>
    </select>

    <input type="number" name="quantity" placeholder="Quantity" required>
    <input type="date" name="expiration_date" placeholder="Expiration Date">
    <input name="unit" placeholder="Unit (pcs, box)">
    <select name="condition_label">
      <option>New</option>
      <option>Expired</option>
      <option>Damaged</option>
      <option>Lost</option>
    </select>

    <select name="status_label">
      <option>Available</option>
      <option>Borrowed</option>
      <option>Low Stock</option>
      <option>Out of Stock</option>
      <option>Disposed</option>
    </select>

     <input name="min_stock" placeholder="Number of stock to alert LOW STOCK">
    <input name="location" placeholder="Location">
    <input name="department" placeholder="Department / Office"> <!-- NEW FIELD -->
    <input type="number" name="supplier_id" placeholder="Supplier ID">
    <input type="file" name="image" accept="image/*">
    <textarea name="description" placeholder="Description"></textarea>

    <button type="submit" class="submit-btn">Generate Barcodes</button>
  </form>

  <button class="back-btn" onclick="window.location.href='generate_barcode.php'">← Back</button>
</div>

</body>
</html>
