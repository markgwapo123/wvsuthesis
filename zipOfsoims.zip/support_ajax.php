<?php
session_start();
require_once 'db_connect.php'; // Ensure your database connection is available

// You may want to add some authentication or user role check here
if (!isset($_SESSION['role'])) {
    header("Location: index.php");
    exit();
}

// Define some example Q&A for the chatbot. You can make this dynamic later from the database.
$faqs = [
    'How to log in?' => 'To log in to SOIMS, you need your account credentials. Go to the login page, enter your username and password, and click "Login".',
    'How to add an item to inventory?' => 'To add an item to the inventory, navigate to the inventory section, click "Add Item", and fill in the required fields.',
    'How to check the stock levels?' => 'You can check stock levels by going to the inventory section. There you can view quantities, item details, and stock status.',
    'What happens if stock runs low?' => 'When stock runs low (below the minimum stock level), the system will notify you, and you may need to restock the items.',
    'How to issue an item to the requestor?' => 'To issue an item to a requestor, go to the order management section, select the item, input the required quantity, and click the "Issue" button. This will update the stock and issue the item to the requestor.',
    'How do I manage suppliers?' => 'To manage suppliers, go to the suppliers section where you can add, edit, and delete supplier records.',
    // Add more FAQ here...
];

// Function to match similar questions using basic word matching
function getAnswer($user_message, $faqs) {
    // Convert the user message to lowercase and remove extra spaces
    $user_message = strtolower(trim($user_message));

    // Look for the word "issue" and "item" or "supply" for issuing item-related questions
    if ((strpos($user_message, 'issue') !== false && (strpos($user_message, 'item') !== false || strpos($user_message, 'supply') !== false))) {
        return 'To issue an item (or supply) to a requestor, go to the order management section, select the item, input the required quantity, and click the "Issue" button. This will update the stock and issue the item to the requestor.';
    }

    // Look for the word "add" and "item" or "supply" for adding item-related questions
    if ((strpos($user_message, 'add') !== false && (strpos($user_message, 'item') !== false || strpos($user_message, 'supply') !== false))) {
        return 'To add an item (or supply) to the inventory, navigate to the inventory section, click "Add Item", and fill in the required fields.';
    }

    // Check for other FAQ types like "stock" or "check"
    if (strpos($user_message, 'stock') !== false && strpos($user_message, 'check') !== false) {
        return 'To check stock levels, click reports in sidebar, go to the stocks report section, where you can view quantities, item details, and stock status.';
    }

    // Check for other FAQ types like "how" or "restock"
    if (strpos($user_message, 'how') !== false && strpos($user_message, 'restock') !== false) {
        return 'To restock an item, click inventory in sidebar, go to the manage item section, where you can see send to procurement button; click whatever item you want to restock and it will sent to procurement officer. They will procure an item and wait until the item arrive so that you can now add item and restock.';
    }

    // Check for other FAQ types like "forgot" or "password"
    if (strpos($user_message, 'forgot') !== false && strpos($user_message, 'password') !== false) {
        return 'If you forgot your password, go to the login page and click on the "Forgot Password" link. Follow the instructions to reset your password via your registered email address.';
    }

    // Check for other FAQ types like "reset" or "password"
    if (strpos($user_message, 'how') !== false && strpos($user_message, 'restock') !== false) {
        return 'To reset your password, go to the login page and click on the "Forgot Password" link. Follow the instructions to reset your password via your registered email address, else if you are logged in, go to your profile click it and type whatever in the textbox and click verify password.
        Next click send OTP and you will receive a OTP from SOIMS on you Gmail, make sure to open the same Gmail as what you used to login in SOIMS. Now, after receiving the otp type it in the OTP textbox and clicked SUBMIT OTP button. if your OTP are correct you can change or reset your password. "Change Password".';
    }



    // If no relevant match is found, return this generic answer
    return 'Sorry, I didn\'t understand that. Please try asking about the SOIMS system.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // User sends a message to the chatbot
    $user_message = trim($_POST['user_message']);
    $response = getAnswer($user_message, $faqs);

    echo json_encode(['response' => $response]);
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SOIMS Support Chat</title>
    <link rel="stylesheet" href="admindasboard.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f1f1f1;
            margin: 0;
            padding: 0;
        }

        .chat-container {
            width: 400px;
            height: 500px;
            background: white;
            position: fixed;
            bottom: 20px;
            right: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .chat-header {
            background: #007bff;
            color: white;
            padding: 15px;
            border-radius: 10px 10px 0 0;
            text-align: center;
        }

        .chat-body {
            padding: 10px;
            height: 350px;
            overflow-y: auto;
            border-bottom: 2px solid #ddd;
        }

        .chat-input {
            display: flex;
            padding: 10px;
            background: #f9f9f9;
            border-radius: 0 0 10px 10px;
        }

        .chat-input input {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .chat-input button {
            width: 15%;
            padding: 10px;
            margin-left: 5px;
            background: #007bff;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .chat-input button:hover {
            background: #0056b3;
        }

        .chat-message {
            margin-bottom: 15px;
        }

        .user-message {
            text-align: right;
            font-weight: bold;
            color: #007bff;
        }

        .bot-message {
            text-align: left;
            color: #333;
        }
    </style>
</head>
<body>

    <div class="chat-container">
        <div class="chat-header">
            <h4>SOIMS Support Chat</h4>
        </div>
        <div class="chat-body" id="chat-body">
            <!-- Messages will be dynamically loaded here -->
        </div>
        <div class="chat-input">
            <input type="text" id="user-message" placeholder="Ask me anything about SOIMS..." />
            <button id="send-message">Send</button>
        </div>
    </div>

    <script>
        // When the "Send" button is clicked
        document.getElementById('send-message').addEventListener('click', function () {
            var userMessage = document.getElementById('user-message').value;
            if (userMessage.trim() !== "") {
                // Add user message to the chat
                addMessageToChat(userMessage, 'user');
                document.getElementById('user-message').value = ''; // Clear input field

                // Send AJAX request to the server
                var formData = new FormData();
                formData.append('user_message', userMessage);

                fetch('support.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    var botResponse = data.response;
                    addMessageToChat(botResponse, 'bot');
                })
                .catch(error => console.error('Error:', error));
            }
        });

        // Function to add messages to the chat
        function addMessageToChat(message, sender) {
            var chatBody = document.getElementById('chat-body');
            var messageDiv = document.createElement('div');
            messageDiv.classList.add('chat-message');

            if (sender === 'user') {
                messageDiv.classList.add('user-message');
                messageDiv.textContent = message;
            } else {
                messageDiv.classList.add('bot-message');
                messageDiv.textContent = message;
            }

            chatBody.appendChild(messageDiv);
            chatBody.scrollTop = chatBody.scrollHeight; // Scroll to the bottom
        }
    </script>

</body>
</html>
