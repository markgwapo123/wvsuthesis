<?php 
session_start();
require_once 'db_connect.php'; // Database connection

// SECURITY: Must be logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['fullname'])) {
    die("Unauthorized access.");
}

$user_id = $_SESSION['user_id'];
$processed_by = $conn->real_escape_string($_SESSION['fullname']);

// Handle success/error messages AFTER redirect
$message = $_SESSION['issuance_message'] ?? "";
$remaining_before = $_SESSION['remaining_before'] ?? "";
$remaining_after  = $_SESSION['remaining_after'] ?? "";

// Clear session messages so they don't repeat
unset($_SESSION['issuance_message']);
unset($_SESSION['remaining_before']);
unset($_SESSION['remaining_after']);

// Get order details
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$order = $conn->query("SELECT * FROM orders WHERE order_id=$order_id")->fetch_assoc();

if (!$order) {
    die("Order not found.");
}

// ===========================
//     HANDLE POST (SUBMIT)
// ===========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $order_id = (int)$_POST['order_id'];
    $issued_qty = (int)$_POST['issued_qty'];
    $item_name = $conn->real_escape_string($order['item_name']);
    $department = $conn->real_escape_string($order['department']);
    $requestor_name = $conn->real_escape_string($order['requestor_name']);
    $receiver = $conn->real_escape_string($_POST['receiver']);  // Receiver input from form

    // Check if issued quantity is valid
    if ($issued_qty < 1) {
        $_SESSION['issuance_message'] = "<p style='color:red;'>Invalid quantity.</p>";
        header("Location: issuance.php?order_id=$order_id");
        exit();
    }

    // Look for inventory and fetch barcode
    $inv = $conn->query("SELECT * FROM inventory WHERE name='$item_name' AND department='$department' LIMIT 1");

    if ($inv->num_rows === 0) {
        $_SESSION['issuance_message'] = "<p style='color:red;'>The item is not in house yet.</p>";
        header("Location: issuance.php?order_id=$order_id");
        exit();
    }

    $invRow = $inv->fetch_assoc();
    $remaining_before = $invRow['quantity'];

    if ($invRow['quantity'] < $issued_qty) {
        $_SESSION['issuance_message'] = "<p style='color:red;'>Not enough stock available.</p>";
        header("Location: issuance.php?order_id=$order_id");
        exit();
    }

    // Get the barcode for the item
    $barcode = $invRow['barcode']; // Assuming barcode is stored in the 'barcode' column in the inventory table

    // Calculate new remaining stock
    $remaining_after = $invRow['quantity'] - $issued_qty;

    // Update inventory (decrease the quantity)
    $conn->query("UPDATE inventory SET quantity = quantity - $issued_qty WHERE inventory_id = {$invRow['inventory_id']}");

    // Update order (decrease the ordered quantity)
    $conn->query("UPDATE orders SET qty = qty - $issued_qty WHERE order_id = $order_id");

    // Insert issuance record with the barcode
    $stmt = $conn->prepare("INSERT INTO issuances (order_id, barcode, item_name, issued_qty, processed_by, issued_at, department, requestor_name, receiver) 
                            VALUES (?, ?, ?, ?, ?, NOW(), ?, ?, ?)");
    $stmt->bind_param("ississss", $order_id, $barcode, $item_name, $issued_qty, $processed_by, $department, $requestor_name, $receiver);

    if ($stmt->execute()) {
        // Log activity
        log_activity($user_id, "Issued $issued_qty pcs of $item_name to $requestor_name (Department: $department)", "Issuance", "Success", $conn);

        // Store output for the next GET (so refresh won't re-submit)
        $_SESSION['issuance_message'] = "<p style='color:green;'>Issued successfully.</p>";
        $_SESSION['remaining_before'] = $remaining_before;
        $_SESSION['remaining_after'] = $remaining_after;
    } else {
        $_SESSION['issuance_message'] = "<p style='color:red;'>Error executing query: " . $stmt->error . "</p>";
    }

    $stmt->close();

    // REDIRECT so refresh does NOT re-submit
    header("Location: issuance.php?order_id=$order_id");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Issuance</title>
    <style>
        body { font-family: Arial; background: #f5f6fa; }
        form { background: #fff; max-width: 600px; margin: 50px auto; padding: 25px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,.1); }
        input { width: 100%; padding: 8px; margin: 8px 0; border-radius: 5px; border: 1px solid #ccc; }
        button { padding: 15px 20px; background: #007bff; color: white; align-items: center; border: none; border-radius: 5px; cursor: pointer; }
        .info-box { padding: 10px; background: #e9ecef; border-radius: 5px; margin-bottom: 10px; }
    </style>
</head>
<body>

<form method="POST">
    <h2>Issue Item</h2>

    <?= $message ?>

    <?php if ($remaining_before !== ""): ?>
    <div class="info-box">
        <strong>Stock Before:</strong> <?= $remaining_before ?><br>
        <strong>Stock After:</strong> <?= $remaining_after ?>
    </div>
    <?php endif; ?>

    <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">

    <label>Receiver:</label>
    <input name="receiver" value="<?= isset($order['receiver']) ? htmlspecialchars($order['receiver']) : ''; ?>" readonly required>

    <label>Requestor:</label>
    <input value="<?= htmlspecialchars($order['requestor_name']) ?>" readonly>

    <label>Department:</label>
    <input value="<?= htmlspecialchars($order['department']) ?>" readonly>

    <label>Item:</label>
    <input value="<?= htmlspecialchars($order['item_name']) ?>" readonly>

    <label>Quantity Ordered:</label>
    <input value="<?= htmlspecialchars($order['qty']) ?>" readonly>

    <label>Quantity to Issue:</label>
    <input name="issued_qty" type="number" min="1" max="<?= $order['qty'] ?>" required>

    <label>Processed By:</label>
    <input value="<?= htmlspecialchars($processed_by) ?>" readonly>

    <a href="order_management.php" style="display:inline-block; margin-top:10px; padding:5px 10px; background:#6c757d; color:white; border-radius:5px; text-decoration:none;">
        ⬅ Back
    </a>

    <button type="submit">Issue Now</button>

</form>

</body>
</html>
