<?php
session_start();
require_once __DIR__ . "/db_connect.php";

/* ===============================
   ACCESS CONTROL
================================ */
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== "end_user") {
    header("Location: index.php?error=Unauthorized");
    exit();
}

/* ===============================
   GET INVENTORY ID
================================ */
$inventory_id = $_GET['inventory_id'] ?? null;
if (!$inventory_id) {
    exit("Invalid inventory ID");
}

/* ===============================
   FETCH INVENTORY ITEM (STRICT)
================================ */
$stmt = $conn->prepare("
    SELECT inventory_id, name, quantity, unit
    FROM inventory
    WHERE inventory_id = ?
");
$stmt->bind_param("i", $inventory_id);
$stmt->execute();
$item = $stmt->get_result()->fetch_assoc();

if (!$item) {
    exit("Item not found");
}

$itemName = $item['name'];
$stock    = (int)$item['quantity'];
$unit     = $item['unit'] ?? 'pcs';

/* ===============================
   SESSION DATA
================================ */
$user_id    = $_SESSION['user_id'];
$fullname   = $_SESSION['fullname'];
$department = $_SESSION['department'];

/* ===============================
   PREVENT DUPLICATE PENDING REQUEST
================================ */
$check = $conn->prepare("
    SELECT request_id
    FROM requests
    WHERE requester_user_id = ?
      AND inventory_id = ?
      AND status = 'Pending'
");
$check->bind_param("ii", $user_id, $inventory_id);
$check->execute();
$exists = $check->get_result()->num_rows;

if ($exists > 0) {
    exit("You already have a pending request for this item.");
}

/* ===============================
   HANDLE FORM SUBMISSION
================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $qty     = (int)$_POST['qty'];
    $remarks = trim($_POST['remarks']);

    if ($qty < 1) {
        exit("Invalid quantity.");
    }

    if ($qty > $stock) {
        exit("Requested quantity exceeds available stock.");
    }

    /* ===============================
       INSERT REQUEST (NO STOCK DEDUCTION YET)
    ================================ */
    $stmt = $conn->prepare("
        INSERT INTO requests
        (requester_user_id, requester_name, requester_department,
         inventory_id, qty_requested, unit, remarks, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')
    ");

    $stmt->bind_param(
        "isssiss",
        $user_id,
        $fullname,
        $department,
        $inventory_id,
        $qty,
        $unit,
        $remarks
    );

    $stmt->execute();

    header("Location: endUserDashboard.php?success=Request+Submitted");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Request Item</title>
    <style>
        body {
            font-family: Arial;
            background: #f4f7fc;
            padding: 20px;
        }
        .box {
            background: white;
            padding: 25px;
            margin: auto;
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        label {
            margin-top: 12px;
            display: block;
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button {
            margin-top: 18px;
            width: 100%;
            padding: 12px;
            background: #0044cc;
            border: none;
            color: white;
            border-radius: 6px;
            cursor: pointer;
            font-size: 15px;
        }
        button:hover {
            background: #0033aa;
        }
    </style>
</head>

<body>

<div class="box">
    <h2>Request Item</h2>

    <form method="POST">

        <label>Item Name</label>
        <input type="text" value="<?= htmlspecialchars($itemName) ?>" readonly>

        <label>Available Quantity</label>
        <input type="text" value="<?= $stock . ' ' . htmlspecialchars($unit) ?>" readonly>

        <label>Quantity Needed</label>
        <input type="number" name="qty" min="1" max="<?= $stock ?>" required>

        <label>Remarks (optional)</label>
        <textarea name="remarks"></textarea>

        <button type="submit">Submit Request</button>

    </form>
</div>

</body>
</html>
