<?php
require_once 'db_connect.php';
require_once 'auth.php'; // Ensure the user has the proper role

// Delete functionality
if (isset($_POST['delete_id']) && is_numeric($_POST['delete_id'])) {
    $deleteId = intval($_POST['delete_id']);
    $conn->query("DELETE FROM notifications WHERE id = $deleteId");
    echo json_encode(['status' => 'success', 'message' => 'Notification deleted successfully']);
    exit();
}

// Get the page number from POST (AJAX)
$page  = isset($_POST['page']) ? max(1, (int)$_POST['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = [];

// Live Search
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(message LIKE '%$s%' 
                 OR type LIKE '%$s%' 
                 OR created_at LIKE '%$s%')";
}

// Filters
if (!empty($_POST['type'])) {
    $t = $conn->real_escape_string($_POST['type']);
    $where[] = "type LIKE '%$t%'";
}

if (!empty($_POST['date_from']) && !empty($_POST['date_to'])) {
    $from = $conn->real_escape_string($_POST['date_from']);
    $to = $conn->real_escape_string($_POST['date_to']);
    $where[] = "DATE(created_at) BETWEEN '$from' AND '$to'";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

// Count total rows (for pagination)
$countSql = "SELECT COUNT(*) AS total FROM notifications $whereSQL";
$countRes = $conn->query($countSql);
$totalRows = $countRes ? (int)$countRes->fetch_assoc()['total'] : 0;
$totalPages = $totalRows > 0 ? ceil($totalRows / $limit) : 1;

// Calculate the range of pages to show (maximum of 3 pages visible at once)
$pageRange = 3;
$startPage = max(1, $page - floor($pageRange / 2));  // Ensure the start page does not go below 1
$endPage = min($startPage + $pageRange - 1, $totalPages);  // Ensure the end page does not exceed total pages

// Fetch page data
$sql = "
    SELECT * 
    FROM notifications 
    $whereSQL 
    ORDER BY created_at DESC 
    LIMIT $limit OFFSET $offset
";
$res = $conn->query($sql);

// Generate table output
echo "
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f6f8;
        margin: 0;
        padding: 0;
    }

    .content-box {
        background: #fff;
        padding: 25px;
        border-radius: 8px;
        max-width: 1200px;
        margin: 20px auto;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    }

    h1 {
        margin: 0;
        padding-bottom: 15px;
        color: #ffffffff;
        font-size: 24px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
        font-size: 14px;
    }

    th {
        background: #007bff;
        color: white;
        text-transform: uppercase;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    .notification {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px;
        border-bottom: 1px solid #ddd;
        cursor: pointer;
        transition: background 0.2s;
    }

    .notification:hover {
        background: #f1f1f1;
    }

    .unread {
        background-color: #f0f8ff;
    }

    .read {
        background-color: #e5e5e5;
    }

    .notif-msg {
        flex: 1;
    }

    .notif-time {
        font-size: 12px;
        color: #777;
    }

    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .page-link {
        padding: 8px 15px;
        margin: 0 5px;
        cursor: pointer;
        border-radius: 4px;
        background: #007bff;
        color: white;
        font-size: 14px;
    }

    .page-link.active {
        background: #0056b3;
    }

    .page-link:hover {
        background: #0056b3;
    }

    .no-result {
        text-align: center;
        color: #888;
    }

</style>

<table class='table'>
  <thead>
    <tr>
      <th>Message</th>
      <th>Type</th>
      <th>Created At</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
";

if ($res && $res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
        $id = (int)$row['id'];
        $message = htmlspecialchars($row['message']);
        $type = htmlspecialchars($row['type']);
        $created_at = date("M d, Y h:i A", strtotime($row['created_at']));
        $is_read = $row['is_read'] ? 'read' : 'unread';

        echo "<tr class='$is_read'>
                <td>$message</td>
                <td>$type</td>
                <td>$created_at</td>
                <td>
                    <a href='notification.php?mark=$id' class='mark-read'>Mark as Read</a> | 
                    <a href='javascript:void(0);' class='delete-notif' data-id='$id'>Delete</a>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='4' class='no-result'>No notifications found.</td></tr>";
}

echo "</tbody></table>";

// Pagination Buttons
echo "<div class='pagination'>";

// Show Previous button if we're not on the first page
if ($page > 1) {
    echo "<span class='page-link' data-page='" . ($page - 1) . "'>⟵ Previous</span>";
}

// Show page numbers (1, 2, 3, etc.)
for ($i = $startPage; $i <= $endPage; $i++) {
    $active = ($i == $page) ? "active" : "";
    echo "<span class='page-link {$active}' data-page='{$i}'>{$i}</span>";
}

// Show Next button if we're not on the last page
if ($page < $totalPages) {
    echo "<span class='page-link' data-page='" . ($page + 1) . "'>Next ⟶</span>";
}

echo "</div>";
?>
