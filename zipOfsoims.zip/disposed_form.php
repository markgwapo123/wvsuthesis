<?php 
require_once 'db_connect.php';

// Check for the barcode from GET or POST
$barcode = $_GET['barcode'] ?? $_POST['barcode'] ?? null;

if ($barcode === null || $barcode === "") {
    die("Error: Barcode not provided.");
}

$barcode = $conn->real_escape_string($barcode);

// Fetch issuance info from the database
$sql = "
    SELECT item_name, department, requestor_name, receiver, processed_by
    FROM issuances
    WHERE barcode = '$barcode'
    LIMIT 1
";

$res = $conn->query($sql);

if ($res->num_rows === 0) {
    die("Error: No issuance record found for this barcode.");
}

// Store query result in $info
$info = $res->fetch_assoc();

// Check if the item exists in the disposals table
$sql_disposal = "
    SELECT 1 FROM disposals WHERE barcode = '$barcode' LIMIT 1
";

$res_disposal = $conn->query($sql_disposal);

// Check if item is disposed
$isDisposed = $res_disposal->num_rows > 0;
$disposalMessage = ""; // Default empty message

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Process the disposal
    $reason = $_POST['reason'] ?? '';

    if ($reason !== '') {
        // Insert into disposals table (dispose the item)
        $dispose_sql = "
            INSERT INTO disposals (barcode, item_name, reason, processed_by)
            VALUES ('$barcode', '" . $conn->real_escape_string($info['item_name']) . "', '$reason', '" . $conn->real_escape_string($info['processed_by']) . "')
        ";

        if ($conn->query($dispose_sql) === TRUE) {
            $disposalMessage = "Item successfully disposed and stored in disposals.";
        } else {
            $disposalMessage = "Error: Failed to dispose item.";
        }
    } else {
        $disposalMessage = "Error: Reason for disposal is required.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dispose Item</title>
    <link href="assets\bootstrap-5.3.2-dist\css\bootstrap.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #143ab7, #1a73e8);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding-top: 50px;
        }

        .container {
            width: 520px;
            background: #ffffff;
            padding: 35px 32px;
            border-radius: 18px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.18);
            animation: fadeIn 0.35s ease;
        }

        h2 {
            text-align: center;
            color: #143ab7;
            font-size: 26px;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .info-box {
            background: #f1f5ff;
            padding: 18px 20px;
            border-radius: 14px;
            margin-bottom: 25px;
            border-left: 4px solid #143ab7;
        }

        .info-box p {
            margin: 6px 0;
            font-size: 14px;
            color: #333;
        }

        label {
            font-weight: 600;
            font-size: 15px;
            display: block;
            margin-bottom: 8px;
            color: #222;
        }

        textarea {
            width: 100%;
            min-height: 110px;
            padding: 12px;
            border-radius: 12px;
            border: 1px solid #d0d7e2;
            background: #fafafa;
            font-size: 14px;
            resize: vertical;
            transition: .25s ease;
        }

        textarea:focus {
            border-color: #1a73e8;
            background: #fff;
            box-shadow: 0 0 6px rgba(26,115,232,0.25);
            outline: none;
        }

        button {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            background: #d93025;
            color: #fff;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 600;
            transition: 0.25s ease;
            margin-top: 12px;
        }

        button:hover {
            background: #b72820;
            box-shadow: 0 6px 14px rgba(217,48,37,0.25);
            transform: translateY(-2px);
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
            font-weight: bold;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="container">

    <h2>Dispose Item</h2>

    <?php if (isset($info)): ?>
        <div class="info-box">
            <p><strong>Item:</strong> <?= htmlspecialchars($info['item_name']) ?></p>
            <p><strong>Department:</strong> <?= htmlspecialchars($info['department']) ?></p>
            <p><strong>Requestor:</strong> <?= htmlspecialchars($info['requestor_name']) ?></p>
            <p><strong>Receiver:</strong> <?= htmlspecialchars($info['receiver']) ?></p>
        </div>
    <?php else: ?>
        <div class="info-box">
            <p style="color: red;">Error: Could not fetch the item details.</p>
        </div>
    <?php endif; ?>

    <!-- Success Message -->
    <?php if ($disposalMessage !== ""): ?>
        <div class="success-message">
            <?= htmlspecialchars($disposalMessage) ?>
        </div>
    <?php endif; ?>

    <form method="POST">

        <!-- Hidden fields -->
        <input type="hidden" name="barcode" value="<?= htmlspecialchars($barcode) ?>">
        <input type="hidden" name="item_name" value="<?= htmlspecialchars($info['item_name']) ?>">
        <input type="hidden" name="department" value="<?= htmlspecialchars($info['department']) ?>">
        <input type="hidden" name="requestor_name" value="<?= htmlspecialchars($info['requestor_name']) ?>">
        <input type="hidden" name="receiver" value="<?= htmlspecialchars($info['receiver']) ?>">
        <input type="hidden" name="processed_by" value="<?= htmlspecialchars($info['processed_by']) ?>">

        <label>Reason for Disposal:</label>
        <textarea name="reason" placeholder="Explain why this item needs to be disposed..." required></textarea>

        <button type="submit">Dispose Item</button>
    </form>

</div>

</body>
</html>
