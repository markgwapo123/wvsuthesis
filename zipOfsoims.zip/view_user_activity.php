<?php
require_once 'db_connect.php';

// Load theme
$settingsQuery = $conn->query("SELECT * FROM user_settings WHERE user_id = 1 LIMIT 1");
$settings = ($settingsQuery && $settingsQuery->num_rows > 0)
    ? $settingsQuery->fetch_assoc()
    : ['theme' => 'light'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Activity Log</title>
  <link rel="stylesheet" href="admindasboard.css">

  <style>
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th, td { border: 1px solid #ccc; padding: 6px; text-align: left; font-size: 14px; }
    input, select { padding: 6px; margin: 4px 0; }
    button { padding: 6px 10px; border: 1px solid #888; background: #f7f7f7; cursor: pointer; }
    button:hover { background:#e2e2e2; }
    th.sortable { cursor: pointer; }
    th.sortable::after { content: ' ⇅'; font-size: 11px; color:#555; }

    #logModalOverlay {
      display:none;
      position:fixed;
      top:0; left:0; right:0; bottom:0;
      background:rgba(0,0,0,0.5);
      justify-content:center;
      align-items:center;
      z-index:9999;
    }
    #logModal {
      background:#fff;
      border-radius:8px;
      padding:20px;
      max-width:600px;
      width:90%;
      max-height:80vh;
      overflow-y:auto;
      box-shadow:0 4px 15px rgba(0,0,0,0.3);
      font-size:14px;
    }
    #logModalClose {
      float:right;
      border:none;
      background:#dc3545;
      color:#fff;
      padding:4px 8px;
      border-radius:4px;
      cursor:pointer;
      font-size:12px;
    }
    pre.ua-block {
      background:#f8f9fa;
      padding:8px;
      border-radius:4px;
      font-size:12px;
      white-space:pre-wrap;
      word-wrap:break-word;
    }
  </style>

</head>

<body class="<?= ($settings['theme'] == 'dark') ? 'dark-mode' : '' ?>">
<div class="dashboard">

  <?php include 'sidebar.php'; ?>

  <main class="main-content">
    <div class="inventory-container">

      <header class="header">
        <h1>User Activity Log</h1>

        <div class="search-bar">
          <input type="text" id="liveSearch" placeholder="Live search logs...">
        </div>
      </header>

      <div class="content-box">

        <div class="quick-filter" style="margin-bottom:8px;">
          <button type="button" onclick="setQuickFilter('today')">Today</button>
          <button type="button" onclick="setQuickFilter('week')">This Week</button>
          <button type="button" onclick="setQuickFilter('month')">This Month</button>
        </div>

        <div class="filter-bar">
          <form id="filterForm">
            <label>User ID:</label>
            <input type="text" name="uid">

            <label>Module:</label>
            <input type="text" name="module">

            <label>Action:</label>
            <input type="text" name="action">

            <label>Device:</label>
            <input type="text" name="device">

            <label>From:</label>
            <input type="date" name="from">

            <label>To:</label>
            <input type="date" name="to">

            <button type="submit">Apply Filters</button>
          </form>
        </div>

        <div class="table-placeholder" id="activityTable">
          Loading logs...
        </div>

        <div style="margin-top: 20px;">
          <button type="button" onclick="downloadCSV()">Download CSV (Filtered)</button>
          <button type="button" onclick="downloadExcel()">Download Excel</button>
          <button type="button" onclick="downloadPDF()">Download PDF</button>
        </div>

      </div>
    </div>
  </main>
</div>

<div id="logModalOverlay">
  <div id="logModal">
    <button id="logModalClose">Close</button>
    <h2>Log Details</h2>
    <div id="logModalContent"></div>
  </div>
</div>

<script>

// DEBUG TEST
console.log("AJAX TEST — script loaded");

/* ============================
   LIVE SEARCH
============================ */
document.getElementById('liveSearch').addEventListener('keyup', loadActivityLogs);

/* ============================
   QUICK FILTER LOGIC
============================ */
function setQuickFilter(type) {
  let today = new Date().toISOString().split("T")[0];
  let from = today;

  if (type === "week") {
    let d = new Date();
    d.setDate(d.getDate() - 7);
    from = d.toISOString().split("T")[0];
  }
  if (type === "month") {
    let d = new Date();
    d.setMonth(d.getMonth() - 1);
    from = d.toISOString().split("T")[0];
  }

  document.querySelector("input[name='from']").value = from;
  document.querySelector("input[name='to']").value = today;

  loadActivityLogs();
}

/* ============================
   FILTER FORM SUBMIT
============================ */
document.getElementById('filterForm').addEventListener('submit', e => {
  e.preventDefault();
  loadActivityLogs();
});

/* ============================
   AJAX LOADER WITH PAGINATION
============================ */
function loadActivityLogs(page = 1) {
  console.log("AJAX CALLING… page:", page);

  let formData = new FormData(document.getElementById('filterForm'));
  formData.append('live', document.getElementById('liveSearch').value);
  formData.append('page', page); // ★ NEW

  fetch('/SUPPLY_OFFICE_first/search_activity_ajax.php', {
    method: 'POST',
    body: formData
  })
  .then(r => r.text())
  .then(html => {
    console.log("AJAX RESPONSE RECEIVED");
    document.getElementById("activityTable").innerHTML = html;

    initTableSorting();
    initDetailsButtons();
    initPaginationButtons(); // ★ NEW
  })
  .catch(err => console.error("AJAX ERROR:", err));
}

/* ============================
   SORTING
============================ */
function initTableSorting() {
  const table = document.querySelector("#activityTable table");
  if (!table) return;

  const headers = table.querySelectorAll("th.sortable");
  headers.forEach((th, index) => {
    th.addEventListener("click", () => {
      let tbody = table.querySelector("tbody");
      let rows = Array.from(tbody.querySelectorAll("tr"));
      let direction = th.getAttribute("data-sort") === "asc" ? "desc" : "asc";
      th.setAttribute("data-sort", direction);

      rows.sort((a, b) => {
        let A = a.children[index].innerText.trim();
        let B = b.children[index].innerText.trim();
        return direction === "asc" ? A.localeCompare(B) : B.localeCompare(A);
      });

      rows.forEach(r => tbody.appendChild(r));
    });
  });
}

/* ============================
   MODAL DETAILS VIEW
============================ */
function initDetailsButtons() {
  document.querySelectorAll(".view-details-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      let parsed = parseUserAgent(this.dataset.device);

      document.getElementById("logModalContent").innerHTML = `
        <div><b>Log ID:</b> ${this.dataset.logId}</div>
        <div><b>User ID:</b> 
          <a href="view_record.php?type=user&id=${this.dataset.userId}" target="_blank">${this.dataset.userId}</a>
        </div>
        <div><b>Action:</b> ${this.dataset.action}</div>
        <div><b>Module:</b> ${this.dataset.module}</div>
        <div><b>Status:</b> ${this.dataset.status}</div>
        <div><b>IP:</b> ${this.dataset.ip}</div>
        <div><b>Date:</b> ${this.dataset.createdAt}</div>
        <hr>
        <h3>Device Details</h3>
        <div><b>OS:</b> ${parsed.os}</div>
        <div><b>Browser:</b> ${parsed.browser}</div>
        <div><b>Device Type:</b> ${parsed.deviceType}</div>
        <pre class="ua-block">${parsed.ua}</pre>
      `;

      document.getElementById("logModalOverlay").style.display = "flex";
    });
  });
}

document.getElementById("logModalClose").addEventListener("click", () => {
  document.getElementById("logModalOverlay").style.display = "none";
});

/* ============================
   PAGINATION BUTTON HANDLER
============================ */
function initPaginationButtons() {
  document.querySelectorAll(".pagination-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      let page = this.dataset.page;
      loadActivityLogs(page);
    });
  });
}

/* ============================
   EXPORT CSV (FIXED)
============================ */
function downloadCSV() {
  let table = document.querySelector("#activityTable table");
  if (!table) return alert("No data to export");

  let rows = table.querySelectorAll("tr");
  let csv = [];

  rows.forEach(row => {
    let cols = row.querySelectorAll("th,td");
    let data = [];

    cols.forEach(col => {
      let text = col.innerText.replace(/(\r\n|\n|\r)/gm, " ").trim();
      data.push(`"${text.replace(/"/g, '""')}"`);
    });

    csv.push(data.join(","));
  });

  let blob = new Blob([csv.join("\n")], { type: "text/csv" });
  let a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "user_activity_filtered.csv";
  a.click();
}

/* ============================
   EXPORT EXCEL
============================ */
function downloadExcel() {
  const table = document.querySelector('#activityTable table');
  if (!table) return alert("No data to export");

  let html = table.outerHTML.replace(/ /g, '%20');
  let a = document.createElement("a");
  a.href = 'data:application/vnd.ms-excel,' + html;
  a.download = "user_activity_filtered.xls";
  a.click();
}

/* ============================
   EXPORT PDF
============================ */
function downloadPDF() {
  const table = document.querySelector('#activityTable table');
  if (!table) return alert("No data");

  const { jsPDF } = window.jspdf;
  let doc = new jsPDF("l", "pt", "a4");

  doc.text("User Activity Log", 40, 40);

  doc.autoTable({
    html: "#activityTable table",
    startY: 60,
    styles: { fontSize: 8 },
    theme: "grid"
  });

  doc.save("user_activity_filtered.pdf");
}

/* INITIAL LOAD */
loadActivityLogs();
</script>
<script>
initTableModule({
    ajaxUrl: "/SUPPLY_OFFICE_first/search_activity_ajax.php",
    filterForm: "#filterForm",
    liveSearch: "#liveSearch",
    tableContainer: "#activityTable",

    modalOverlay: "#logModalOverlay",
    modalClose: "#logModalClose",
    modalContent: "#logModalContent",

    exportCSVBtn: "#btnCSV",
    exportExcelBtn: "#btnExcel",
    exportPDFBtn: "#btnPDF",

    exportFileName: "user_activity_logs",
    exportTitle: "User Activity Logs"
});
</script>


<script src="chart.umd.min.js"></script>
<script src="admindashboard.js" defer></script>
<script src="assets/js/jspdf.umd.min.js"></script>
<script src="assets/js/jspdf.plugin.autotable.min.js"></script>

</body>
</html>
