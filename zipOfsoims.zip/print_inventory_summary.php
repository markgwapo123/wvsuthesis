<?php require_once 'db_connect.php'; ?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Print inventory_summary</title>
<style>body{font-family:Arial}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:6px}@media print{.noprint{display:none}}</style>
</head><body>
<h2>Inventory_Summary Report</h2>
<button class="noprint" onclick="window.print()">Print / Save as PDF</button>
<table><thead><tr>
<?php
$res=$conn->query("SELECT item_id,code,barcode,name,category,quantity,unit,condition_label,status_label,location,updated_at FROM items");
if($row=$res->fetch_assoc()){ foreach(array_keys($row) as $h) echo "<th>".htmlspecialchars($h)."</th>"; echo "</tr></thead><tbody>"; echo "<tr>"; foreach($row as $v) echo "<td>".htmlspecialchars($v)."</td>"; echo "</tr>"; }
while($r=$res->fetch_assoc()){ echo "<tr>"; foreach($r as $v) echo "<td>".htmlspecialchars($v)."</td>"; echo "</tr>"; }
?>
</tbody></table>
</body></html>