<?php
require_once __DIR__ . '/auth.php';
allow_roles(['admin']);
require_once __DIR__ . '/db_connect.php';

// theme
$settingsQuery = $conn->query("SELECT * FROM user_settings WHERE user_id = 1 LIMIT 1");
$settings = ($settingsQuery && $settingsQuery->num_rows > 0)
  ? $settingsQuery->fetch_assoc()
  : ['theme' => 'light'];

// allowed roles for assignment
$ALLOWED_ROLES = ['admin', 'subadmin', 'procurement'];

$message = "";

// HANDLE ROLE UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_role'])) {
    $userId = isset($_POST['user_id']) ? (int) $_POST['user_id'] : 0;
    $newRole = $_POST['role'] ?? '';

    if ($userId > 0 && in_array($newRole, $ALLOWED_ROLES, true)) {
        $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->bind_param("si", $newRole, $userId);
        if ($stmt->execute()) {
            $message = "✅ Role updated successfully for User ID {$userId}.";
        } else {
            $message = "❌ Failed to update role. Please try again.";
        }
        $stmt->close();
    } else {
        $message = "❌ Invalid role or user.";
    }
}

// PAGINATION + FILTERS (similar style to your sample)
$page  = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = [];
$params = [];
$types  = "";

// live search (name, email, role)
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $like = '%' . $search . '%';
    $where[] = "(first_name LIKE ? OR middle_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR role LIKE ?)";
    $params = array_merge($params, [$like, $like, $like, $like, $like]);
    $types .= "sssss";
}

// role filter
$roleFilter = trim($_GET['role_filter'] ?? '');
if ($roleFilter !== '') {
    $where[] = "role = ?";
    $params[] = $roleFilter;
    $types .= "s";
}

// created_from filter
$createdFrom = trim($_GET['created_from'] ?? '');
if ($createdFrom !== '') {
    $where[] = "DATE(created_at) >= ?";
    $params[] = $createdFrom;
    $types .= "s";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

// COUNT total
$countSql = "SELECT COUNT(*) AS total FROM users $whereSQL";
$countStmt = $conn->prepare($countSql);
if (!empty($where)) {
    $countStmt->bind_param($types, ...$params);
}
$countStmt->execute();
$countRes = $countStmt->get_result();
$totalRows = ($countRes && $row = $countRes->fetch_assoc()) ? (int)$row['total'] : 0;
$countStmt->close();

$totalPages = max(1, ceil($totalRows / $limit));

// FETCH USERS
$listSql = "
    SELECT id,
           first_name,
           middle_name,
           last_name,
           role,
           email,
           created_at
    FROM users
    $whereSQL
    ORDER BY id DESC
    LIMIT ? OFFSET ?
";
$listStmt = $conn->prepare($listSql);

// bind again with LIMIT/OFFSET
if (!empty($where)) {
    // add limit/offset types at the end
    $typesList = $types . "ii";
    $paramsList = $params;
    $paramsList[] = $limit;
    $paramsList[] = $offset;
    $listStmt->bind_param($typesList, ...$paramsList);
} else {
    $listStmt->bind_param("ii", $limit, $offset);
}

$listStmt->execute();
$usersRes = $listStmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Assign Roles & Permissions</title>
  <link rel="stylesheet" href="admindasboard.css">
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    th,
    td {
      border: 1px solid #ccc;
      padding: 6px;
      text-align: left;
    }

    form {
      margin-top: 10px;
    }

    input,
    select {
      padding: 6px;
      margin: 1px 0;
      width: 100%;
    }

    button {
      padding: 6px 10px;
      background: #eaeaea;
      border: 1px solid #777;
      cursor: pointer;
    }

    .filters {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 10px;
      margin-bottom: 10px;
    }

    .filters .filter-group {
      flex: 1 1 200px;
    }

    .filters label {
      font-size: 0.9rem;
      display: block;
      margin-bottom: 2px;
    }

    .pagination {
      margin-top: 15px;
    }

    .pagination .page-link {
      margin: 0 3px;
      padding: 3px 7px;
      border: 1px solid #ccc;
      cursor: pointer;
      display: inline-block;
    }

    .pagination .active {
      background: #444;
      color: #fff;
    }

    .message {
      margin-top: 10px;
      margin-bottom: 10px;
      font-size: 0.95rem;
    }

    .role-select {
      width: auto;
      min-width: 120px;
    }

    .action-buttons {
      display: flex;
      gap: 5px;
      flex-wrap: wrap;
    }

    .action-buttons button {
      width: auto;
    }

    .search-bar input {
      width: 200px;
    }
  </style>
</head>

<body class="<?= $settings['theme'] == 'dark' ? 'dark-mode' : '' ?>">

  <div class="dashboard">
    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <main class="main-content">
      <div class="inventory-container">
        <!-- Header -->
        <header class="header">
          <h1>Assign Roles & Permissions</h1>
          <!-- Search bar uses GET 'search' -->
          <form method="get" class="search-bar">
            <input type="text" name="search" placeholder="Search name, email, role"
                   value="<?= htmlspecialchars($search) ?>">
            <button type="submit"><span>&#128269;</span></button>
          </form>
        </header>

        <!-- Content Box -->
        <div class="content-box">

          <?php if ($message): ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
          <?php endif; ?>

          <!-- Filters -->
          <form method="get" class="filters">
            <div class="filter-group">
              <label for="role_filter">Filter by Role:</label>
              <select name="role_filter" id="role_filter">
                <option value="">All roles</option>
                <?php foreach ($ALLOWED_ROLES as $r): ?>
                  <option value="<?= $r ?>" <?= $roleFilter === $r ? 'selected' : '' ?>>
                    <?= ucfirst($r) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="filter-group">
              <label for="created_from">Created From:</label>
              <input type="date" name="created_from" id="created_from"
                     value="<?= htmlspecialchars($createdFrom) ?>">
            </div>

            <div class="filter-group" style="align-self:flex-end;">
              <button type="submit">Apply Filters</button>
            </div>
          </form>

          <!-- Users Table -->
          <h2>Users & Role Assignment</h2>

          <table>
            <thead>
              <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Role</th>
                <th>Email</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php
              if (!$usersRes || $usersRes->num_rows === 0): ?>
                <tr>
                  <td colspan="5">No users found.</td>
                </tr>
              <?php
              else:
                while ($u = $usersRes->fetch_assoc()):
                  $fullName = trim($u['first_name'] . ' ' . $u['middle_name'] . ' ' . $u['last_name']);
                  if ($fullName === '') $fullName = '(No name)';
              ?>
                <tr>
                  <td><?= htmlspecialchars($u['id']) ?></td>
                  <td><?= htmlspecialchars($fullName) ?></td>
                  <td>
                    <!-- Inline form per row to update role -->
                    <form method="post" style="display:flex; gap:5px; align-items:center;">
                      <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                      <select name="role" class="role-select">
                        <?php
                        $currentRole = $u['role'];
                        foreach ($ALLOWED_ROLES as $roleOption):
                          $sel = ($currentRole === $roleOption) ? 'selected' : '';
                        ?>
                          <option value="<?= $roleOption ?>" <?= $sel ?>>
                            <?= ucfirst($roleOption) ?>
                          </option>
                        <?php endforeach; ?>
                      </select>
                      <button type="submit" name="update_role">Save</button>
                    </form>
                  </td>
                  <td><?= htmlspecialchars($u['email']) ?></td>
                  <td>
                    <div class="action-buttons">
                      <button type="button"
                        onclick="window.location='edit_record.php?type=user&id=<?= (int)$u['id'] ?>'">
                        Edit
                      </button>
                      <button type="button"
                        onclick="if(confirm('Delete this user?')) window.location='delete_record.php?type=user&id=<?= (int)$u['id'] ?>';">
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              <?php
                endwhile;
              endif;
              ?>
            </tbody>
          </table>

          <!-- Pagination -->
          <div class="pagination">
            <?php
            // build base query string for links (keep filters/search)
            $qs = $_GET;
            if (!isset($qs['page'])) $qs['page'] = 1;

            if ($page > 1) {
                $qs['page'] = $page - 1;
                echo "<a class='page-link' href='?" . http_build_query($qs) . "'>Previous</a>";
            }

            for ($i = 1; $i <= $totalPages; $i++) {
                $qs['page'] = $i;
                $active = ($i == $page) ? "active" : "";
                echo "<a class='page-link $active' href='?" . http_build_query($qs) . "'>$i</a>";
            }

            if ($page < $totalPages) {
                $qs['page'] = $page + 1;
                echo "<a class='page-link' href='?" . http_build_query($qs) . "'>Next</a>";
            }
            ?>
          </div>

        </div>

      </div>
    </main>
  </div>

  <script src="chart.umd.min.js"></script>
  <script src="admindashboard.js" defer></script>

</body>
</html>
<?php
$listStmt->close();
?>
