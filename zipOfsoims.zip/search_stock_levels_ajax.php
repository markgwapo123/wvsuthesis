<?php
require_once "db_connect.php";

/*-------------------------------------------------------
  LOAD SETTINGS
-------------------------------------------------------*/
$settings = $conn->query("SELECT * FROM user_settings WHERE user_id = 1 LIMIT 1")->fetch_assoc();
$lowStock = $settings['low_stock_threshold'] ?? 10;

/*-------------------------------------------------------
  PAGINATION
-------------------------------------------------------*/
$page   = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
$limit  = 20;
$offset = ($page - 1) * $limit;

/*-------------------------------------------------------
  FILTERS + LIVE SEARCH
-------------------------------------------------------*/
$where = [];

if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(name LIKE '%$s%' OR department LIKE '%$s%')";
}

if (!empty($_POST['department'])) {
    $d = $conn->real_escape_string($_POST['department']);
    $where[] = "department LIKE '%$d%'";
}

$whereSQL = $where ? ("WHERE " . implode(" AND ", $where)) : "";

/*-------------------------------------------------------
  COUNT ROWS FOR PAGINATION
-------------------------------------------------------*/
$countRes = $conn->query("
    SELECT COUNT(*) AS total FROM (
        SELECT name FROM inventory 
        $whereSQL
        GROUP BY name, department
    ) AS grouped
");
$totalRows = $countRes->fetch_assoc()['total'];
$totalPages = max(1, ceil($totalRows / $limit));

/*-------------------------------------------------------
  MAIN QUERY — GROUP BY ITEM
-------------------------------------------------------*/
$sql = "
SELECT 
    MIN(inventory_id) AS inventory_id,
    name,
    category,
    department,
    status_label,
    SUM(quantity) AS quantity,
    min_stock
FROM inventory
$whereSQL
GROUP BY name, category, department, min_stock
ORDER BY name ASC
LIMIT $limit OFFSET $offset
";

$res = $conn->query($sql);

/*-------------------------------------------------------
  OUTPUT TABLE
-------------------------------------------------------*/
echo "
<table class='table'>
<thead>
<tr>
  <th>Name</th>
  <th>Qty</th>
  <th>Department</th>
  <th>Status</th>
  <th>Min Stock</th>
</tr>
</thead>
<tbody>
";

if ($res->num_rows > 0) {

    while ($r = $res->fetch_assoc()) {

        $cls = "";

        if ((int)$r["quantity"] <= (int)$r["min_stock"]) {
            $cls = "low"; // highlight
        }

        echo "
        <tr class='$cls'>
            <td>" . htmlspecialchars($r['name']) . "</td>
            <td>{$r['quantity']}</td>
            <td>" . htmlspecialchars($r['department']) . "</td>
            <td>" . htmlspecialchars($r['status_label']) . "</td>
            <td>{$r['min_stock']}</td>
        </tr>";
    }

} else {
    echo "<tr><td colspan='4'>No records found.</td></tr>";
}

echo "</tbody></table>";

/*-------------------------------------------------------
  PAGINATION
-------------------------------------------------------*/
echo "<div class='pagination'>";

if ($page > 1) {
    echo "<span class='page-link' data-page='".($page-1)."'>Previous</span>";
}

for ($i = 1; $i <= $totalPages; $i++) {
    $active = ($i == $page) ? "active" : "";
    echo "<span class='page-link $active' data-page='$i'>$i</span>";
}

if ($page < $totalPages) {
    echo "<span class='page-link' data-page='".($page+1)."'>Next</span>";
}

echo "</div>";

