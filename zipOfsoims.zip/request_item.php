<?php 
require_once 'db_connect.php'; // Database connection

// SECURITY: Must be logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['fullname'])) {
    die("Unauthorized access.");
}

$user_id = $_SESSION['user_id'];
$processed_by = $conn->real_escape_string($_SESSION['fullname']);  // Ensure this is set

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'create') {
    // Collect form data
    $receiver = isset($_POST['receiver']) ? $_POST['receiver'] : '';  // Added check for receiver
    $requestor = isset($_POST['requestor']) ? $_POST['requestor'] : '';
    $department = isset($_POST['department']) ? $_POST['department'] : '';
    $item_name = isset($_POST['item_name']) ? $_POST['item_name'] : '';
    $qty = isset($_POST['qty']) ? $_POST['qty'] : '';
    $order_date = isset($_POST['order_date']) ? $_POST['order_date'] : '';
    $expected_date = isset($_POST['expected_date']) ? $_POST['expected_date'] : '';
    $unit = isset($_POST['unit']) ? $_POST['unit'] : '';

    // Check if required fields are provided
    if (empty($receiver) || empty($requestor) || empty($department) || empty($item_name) || empty($qty) || empty($order_date) || empty($expected_date)) {
        $error_message = "All fields are required!";
    } else {
        // Insert the order into the database
        $sql = "INSERT INTO orders (receiver, requestor_name, department, item_name, qty, order_date, expected_date, processed_by, unit)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        // Bind parameters and check if they're correct
        if ($stmt) {
            $stmt->bind_param("sssssssss", $receiver, $requestor, $department, $item_name, $qty, $order_date, $expected_date, $processed_by, $unit);

            if ($stmt->execute()) {
                // Success message
                $success_message = "Order has been placed successfully!";
                // Redirect after successful form submission to prevent resubmission
                header("Location: request_item.php?success=true");
                exit();  // Make sure the rest of the code doesn't run after redirect
            } else {
                // Error message
                $error_message = "There was an error placing the order. Please try again.";
            }
            $stmt->close();
        } else {
            // Handle error if prepare fails
            $error_message = "Error preparing the query.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Order</title>
<link rel="stylesheet" href="assets\bootstrap-5.3.2-dist\css\bootstrap.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #143ab7ff, #143ab7ff);
      margin: 0;
      padding: 0;
      color: #333;
    }

    .main-content {
      max-width: 800px;
      margin: 50px auto;
      background: #fff;
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      animation: fadeIn 0.6s ease;
    }

    h1 {
      text-align: center;
      color: #3b3b98;
      margin-bottom: 25px;
    }

    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
    }

    input,
    select {
      height: 80%;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid #ccd6f6;
      font-size: 14px;
      background-color: #fafaff;
      transition: all 0.3s ease;
    }

    input:focus,
    select:focus {
      outline: none;
      border-color: #2c69daff;
      box-shadow: 0 0 4px rgba(47, 57, 252, 0.3);
    }

    .form-group {
      position: relative;
      margin-top: 20px;
      bottom: 20px;
    }

    .form-group input {
      width: 100%;
      height: 60px;
      padding: 10px 12px;
      font-size: 14px;
    }

    .form-group label {
      position: absolute;
      top: 10px;
      left: 120px;
      color: #777;
      transition: 0.2s;
      pointer-events: none;
    }

    .form-group input:focus+label,
    .form-group input:valid+label {
      top: -10px;
      left: 10px;
      font-size: 12px;
      color: #000;
      background: #fff;
      padding: 0 4px;
    }
    
    .submit-btn {
      grid-column: 1 / 3;
      padding: 12px;
      background-color: #395ffaff;
      color: #fff;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      font-size: 15px;
      transition: background-color 0.3s, transform 0.2s;
    }

    .submit-btn:hover {
      background-color: #180fcaff;
      transform: translateY(-2px);
    }

    .back-btn {
      display: block;
      margin: 25px auto 0;
      background-color: #ff7b9c;
      color: #fff;
      border: none;
      padding: 10px 25px;
      border-radius: 10px;
      font-size: 14px;
      cursor: pointer;
      transition: background 0.3s, transform 0.2s;
    }

    .back-btn:hover {
      background-color: #ff4f7a;
      transform: translateY(-2px);
    }

    /* Success/Error alert */
    .alert {
      background-color: #4CAF50;
      color: white;
      padding: 15px;
      margin-top: 20px;
      text-align: center;
      border-radius: 5px;
      display: none;
    }

    .alert.error {
      background-color: #f44336;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>
<body>
  <div class="main-content">
    <h1><b>Request Item</b></h1>

    <!-- Show success or error message -->
    <?php if (isset($success_message)): ?>
      <div class="alert alert-success"><?= $success_message ?></div>
    <?php elseif (isset($error_message)): ?>
      <div class="alert alert-danger"><?= $error_message ?></div>
    <?php endif; ?>

    <form id="createOrder" enctype="multipart/form-data" method="post" action="request_item.php">
      <input type="hidden" name="action" value="create">

      <div class="grid">
        <div class="form-group">
          <input name="receiver" id="receiver" required>
          <label for="receiver">Receiver</label>
        </div>
        <div class="form-group">
          <input name="requestor" id="requestor" required>
          <label for="requestor">Requestor</label>
        </div>
        <div class="form-group">
          <input name="department" id="department" required>
          <label for="department">Department</label>
        </div>
        <div class="form-group">
          <input name="item_name" id="item_name" required>
          <label for="item_name">Item Name</label>
        </div>
        <div class="form-group">
          <input name="qty" id="qty" type="number" min="1" required>
          <label for="qty">Quantity</label>
        </div>
        <div class="form-group">
          <input type="date" name="order_date" id="order_date" required>
          <label for="order_date">Order Date</label>
        </div>
        <div class="form-group">
          <input type="date" name="expected_date" id="expected_date" required>
          <label for="expected_date">Expected Date Receive</label>
        </div>
        <div class="form-group">
          <input value="<?= htmlspecialchars($processed_by) ?>" readonly>
          <label>Processed By:</label>
        </div>
        <select name="unit">
          <option>Item Unit</option>
          <option>Pieces</option>
          <option>Boxes</option>
          <option>Ream</option>
          <option>Pack</option>
          <option>Case</option>
        </select>
        <button type="submit" class="submit-btn">Submit Request</button>
      </div>
    </form>

    <button class="back-btn" onclick="window.location.href='order_management.php'">← Back to Order Management</button>
  </div>
</body>
</html>
