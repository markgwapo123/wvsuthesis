<?php
require 'db_connect.php';

// Required fields
$required = ['barcode', 'item_name', 'department', 'requestor_name', 'receiver', 'processed_by', 'reason'];

foreach ($required as $field) {
    if (!isset($_POST[$field]) || trim($_POST[$field]) === '') {
        die("Error: Missing required field: $field");
    }
}

$barcode        = $conn->real_escape_string($_POST['barcode']);
$item_name      = $conn->real_escape_string($_POST['item_name']);
$department     = $conn->real_escape_string($_POST['department']);
$requestor_name = $conn->real_escape_string($_POST['requestor_name']);
$receiver       = $conn->real_escape_string($_POST['receiver']);
$processed_by   = $conn->real_escape_string($_POST['processed_by']);
$reason         = $conn->real_escape_string($_POST['reason']);

$sql = "
    INSERT INTO disposals (barcode, item_name, department, requestor_name, receiver, reason, processed_by)
    VALUES (?, ?, ?, ?, ?, ?, ?)
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssss", $barcode, $item_name, $department, $requestor_name, $receiver, $reason, $processed_by);

if ($stmt->execute()) {
    echo "<h2 style='color:green;'>Item disposed successfully.</h2>";
    echo "<a href='dispose_scan.php'>Dispose another item</a>";
} else {
    echo "<h2 style='color:red;'>Database error: " . $stmt->error . "</h2>";
}
