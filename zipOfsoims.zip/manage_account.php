<?php
require_once 'auth.php';
require_once 'db_connect.php';

// Block unauthenticated users
$user = current_user();
if (!$user) {
    header("Location: index.php?error=Unauthorized");
    exit();
}

$user_id = $user['id'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$userdata = $stmt->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Manage Account</title>

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="admindasboard.css">

    <!-- BOOTSTRAP OFFLINE -->
    <link rel="stylesheet" href="assets/bootstrap-5.3.2-dist/css/bootstrap.min.css">

    <style>
        body {
            background: linear-gradient(135deg, #eef2f7, #d9e4f5);
        }

        /* Main container */
        .account-wrapper {
            max-width: 950px;
            margin: 30px auto;
            padding: 25px;
            background: #ffffff;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
            animation: fadeIn 0.6s ease;
        }

        /* Fade animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Profile card */
        .profile-header {
            text-align: center;
            padding: 20px;
            background: linear-gradient(135deg, #007bff, #5aa9ff);
            border-radius: 15px;
            color: white;
            margin-bottom: 20px;
        }

        .profile-img {
            width: 140px;
            height: 140px;
            object-fit: cover;
            border-radius: 50%;
            border: 4px solid #fff;
            margin-top: -70px;
            background: #fff;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.25);
        }

        /* Section box */
        .section-box {
            margin-top: 25px;
            padding: 20px;
            color: #01060cff;
            background: #fafbfc;
            border-radius: 15px;
            border: 1px solid #e0e6ef;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        /* Buttons */
        .save-btn {
            background: #007bff;
            color: white;
            padding: 11px 25px;
            border-radius: 7px;
            border: none;
            font-size: 15px;
            transition: 0.2s;
        }

        .save-btn:hover {
            background: #0056b3;
        }

        /* Toast notification */
        #toastMessage {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 5000;
            display: none;
            padding: 12px 20px;
            color: white;
            background: #28a745;
            border-radius: 7px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            animation: slideDown 0.4s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-15px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Password strength */
        #passwordStrengthText {
            font-size: 13px;
            margin-top: 4px;
        }

        /* Small shake animation for invalid OTP */
        .shake {
            animation: shake 0.25s linear 0s 2;
        }

        @keyframes shake {
            0% {
                transform: translateX(0);
            }

            25% {
                transform: translateX(-4px);
            }

            50% {
                transform: translateX(4px);
            }

            75% {
                transform: translateX(-4px);
            }

            100% {
                transform: translateX(0);
            }
        }
    </style>
</head>

<body>

    <div class="dashboard">
        <?php if ($user['role'] !== 'end_user') {
            include 'sidebar.php';
        } ?>


        <main class="main-content">

            <div id="toastMessage"></div>

            <div class="account-wrapper">

                <!-- HEADER -->
                <div class="profile-header">
                    <h2>Manage Your Account</h2>
                    <p>Update profile information, contact details, and password</p>
                </div>

                <!-- PROFILE PICTURE -->
                <div class="text-center">
                    <img src="<?= htmlspecialchars($userdata['profile_img'] ?: 'default_profile.png') ?>"
                        class="profile-img" id="profilePreview">

                    <form id="profilePicForm" enctype="multipart/form-data" class="mt-3">
                        <input type="file" name="profile_img" accept="image/*" class="form-control w-50 mx-auto" required>
                        <button class="save-btn mt-3">Upload Photo</button>
                    </form>
                </div>

                <!-- SECTION 1: PERSONAL INFO -->
                <div class="section-box">
                    <h4 class="mb-3">Personal Information</h4>
                    <form id="updateInfoForm">

                        <div class="row">
                            <div class="col-md-4">
                                <label>First Name</label>
                                <input type="text" class="form-control" name="first_name"
                                    value="<?= htmlspecialchars($userdata['first_name']) ?>" required>
                            </div>

                            <div class="col-md-4">
                                <label>Middle Name</label>
                                <input type="text" class="form-control" name="middle_name"
                                    value="<?= htmlspecialchars($userdata['middle_name']) ?>">
                            </div>

                            <div class="col-md-4">
                                <label>Last Name</label>
                                <input type="text" class="form-control" name="last_name"
                                    value="<?= htmlspecialchars($userdata['last_name']) ?>" required>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-4">
                                <label>Date of Birth</label>
                                <input type="date" class="form-control" name="dob"
                                    value="<?= htmlspecialchars($userdata['dob']) ?>">
                            </div>
                            <div class="col-md-4">
                                <label>Contact Number</label>
                                <input type="text" class="form-control" name="contact"
                                    value="<?= htmlspecialchars($userdata['contact']) ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label>Email Address</label>
                                <input type="email" class="form-control" name="email"
                                    value="<?= htmlspecialchars($userdata['email']) ?>" required>
                            </div>
                        </div>

                        <button class="save-btn mt-3">Save Changes</button>

                    </form>
                </div>

                <!-- SECTION 2: CHANGE PASSWORD -->
                <div class="section-box">
                    <h4>Change Password</h4>

                    <!-- STEP 1: VERIFY CURRENT PASSWORD -->
                    <form id="verifyPasswordForm">
                        <label>Enter Current Password</label>
                        <input type="password" class="form-control" name="current_password" required>
                        <button class="btn btn-primary mt-2">Verify Password</button>
                    </form>

                    <!-- STEP 2A: DIRECT CHANGE SECTION (IF PASSWORD CORRECT) -->
                    <div id="directChangeSection" class="mt-4" style="display:none;">
                        <h5>Set New Password</h5>
                        <form id="directChangeForm">
                            <label>New Password</label>
                            <input type="password" class="form-control" id="directNewPassword" required>

                            <div class="mt-1">
                                <div class="progress">
                                    <div id="directStrengthBar" class="progress-bar" style="width:0%;"></div>
                                </div>
                                <div id="directStrengthText"></div>
                            </div>

                            <label class="mt-3">Confirm New Password</label>
                            <input type="password" class="form-control" id="directConfirmPassword" required>

                            <button class="btn btn-success mt-3">Save New Password</button>
                        </form>
                    </div>

                    <!-- STEP 2B: OTP METHOD (EMAIL ONLY) -->
                    <div id="otpChoiceSection" class="mt-4" style="display:none;">
                        <p>Your current password is incorrect. You can reset your password via OTP sent to your email:</p>
                        <button type="button" class="btn btn-outline-primary" id="btnOtpEmail">
                            Send OTP to Email (<?= htmlspecialchars($userdata['email']) ?>)
                        </button>
                    </div>

                    <!-- STEP 3: OTP + NEW PASSWORD -->
                    <div class="otp-section mt-4" id="otpSection" style="display:none;">

                        <h5>Verify OTP</h5>

                        <div class="input-group mb-2">
                            <input type="text" class="form-control" name="otp" id="otpInput" placeholder="Enter 6-digit OTP">
                            <button class="btn btn-outline-primary" type="button" id="btnSubmitOtp">Submit OTP</button>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <small id="otpTimerText" class="text-muted"></small>
                            <button type="button" class="btn btn-link p-0" id="btnResendOtp" style="display:none;">
                                Resend OTP
                            </button>
                        </div>

                        <div id="otpError" class="text-danger" style="display:none;">Invalid OTP. Please try again.</div>

                        <!-- NEW PASSWORD AREA (HIDDEN UNTIL OTP IS VERIFIED) -->
                        <div id="newPasswordArea" style="display:none;">

                            <label class="mt-3">New Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="new_password" id="otpNewPassword">
                                <span class="input-group-text toggle-pass" data-target="#otpNewPassword" style="cursor:pointer;">👁</span>
                            </div>

                            <div class="mt-1">
                                <div class="progress">
                                    <div id="otpStrengthBar" class="progress-bar" style="width:0%;"></div>
                                </div>
                                <div id="otpStrengthText"></div>
                            </div>

                            <label class="mt-3">Confirm Password</label>
                            <div class="input-group">
                                <input type="password" class="form-control" name="confirm_password" id="otpConfirmPassword">
                                <span class="input-group-text toggle-pass" data-target="#otpConfirmPassword" style="cursor:pointer;">👁</span>
                            </div>

                            <button class="btn btn-success mt-3" id="btnSubmitNewPassword">Change Password</button>

                        </div>
                    </div>
                </div>
        </main>
    </div>

    <!-- Confirm modal -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Password Change</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to update your password?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmChangeBtn">Yes, change it</button>
                </div>
            </div>
        </div>
    </div>

    <!-- SCRIPTS (OFFLINE) -->
    <script src="assets/js/jquery-3.7.1.min.js"></script>
    <script src="assets/bootstrap-5.3.2-dist/js/bootstrap.bundle.min.js"></script>
    <script src="admindashboard.js" defer></script>
    <script>
        let lastVerifiedPassword = null;
        let pendingChangeMode = null;
        let pendingChangeData = {};
        let confirmModal = null;

        // OTP extra controls
        let otpAttempts = 0;
        const maxOtpAttempts = 5;
        let otpExpireTimer = null;
        let otpResendCooldownTimer = null;
        let otpExpireAt = null;
        let otpCooldownRemaining = 0;

        function showToast(msg, type = "success") {
            let toast = $("#toastMessage");
            toast.css("background", type === "error" ? "#dc3545" : "#28a745");
            toast.text(msg).fadeIn();
            setTimeout(() => toast.fadeOut(), 2500);
        }

        function evaluateStrength(pwd) {
            let score = 0;
            if (!pwd) return {
                score: 0,
                label: "",
                color: "",
                width: 0
            };
            if (pwd.length >= 8) score++;
            if (/[A-Z]/.test(pwd)) score++;
            if (/[0-9]/.test(pwd)) score++;
            if (/[^A-Za-z0-9]/.test(pwd)) score++;

            let label = "Weak";
            let color = "bg-danger";
            let width = 25;

            if (score >= 3) {
                label = "Medium";
                color = "bg-warning";
                width = 60;
            }
            if (score >= 4) {
                label = "Strong";
                color = "bg-success";
                width = 100;
            }

            return {
                score,
                label,
                color,
                width
            };
        }

        function bindStrengthMeter(inputSelector, barSelector, textSelector) {
            $(inputSelector).on('input', function() {
                const val = $(this).val();
                const res = evaluateStrength(val);
                const bar = $(barSelector);
                const txt = $(textSelector);

                bar.removeClass("bg-danger bg-warning bg-success");
                if (res.color) bar.addClass(res.color);
                bar.css("width", (res.width || 0) + "%");
                txt.text(res.label ? ("Strength: " + res.label) : "");
            });
        }

        // Format seconds to MM:SS
        function formatTime(seconds) {
            seconds = Math.max(0, seconds);
            const m = Math.floor(seconds / 60);
            const s = seconds % 60;
            return (m < 10 ? "0" + m : m) + ":" + (s < 10 ? "0" + s : s);
        }

        // Start OTP expiry countdown (5 mins)
        function startOtpExpiryCountdown() {
            if (otpExpireTimer) clearInterval(otpExpireTimer);

            otpExpireTimer = setInterval(function() {
                if (!otpExpireAt) return;
                const now = Date.now();
                const remainingMs = otpExpireAt - now;
                const remainingSec = Math.round(remainingMs / 1000);

                if (remainingSec <= 0) {
                    $("#otpTimerText").text("OTP expired. Please resend.");
                    clearInterval(otpExpireTimer);
                    otpExpireTimer = null;
                    return;
                }

                $("#otpTimerText").text("OTP expires in " + formatTime(remainingSec));
            }, 1000);
        }

        // Start resend cooldown (e.g. 30 seconds)
        function startResendCooldown(seconds) {
            otpCooldownRemaining = seconds;
            $("#btnResendOtp").prop("disabled", true);

            if (otpResendCooldownTimer) clearInterval(otpResendCooldownTimer);

            otpResendCooldownTimer = setInterval(function() {
                otpCooldownRemaining--;
                if (otpCooldownRemaining <= 0) {
                    clearInterval(otpResendCooldownTimer);
                    otpResendCooldownTimer = null;
                    $("#btnResendOtp").prop("disabled", false).text("Resend OTP");
                } else {
                    $("#btnResendOtp").text("Resend OTP (" + otpCooldownRemaining + "s)");
                }
            }, 1000);
        }

        $(function() {
            const modalEl = document.getElementById('confirmModal');
            if (modalEl) confirmModal = new bootstrap.Modal(modalEl);

            bindStrengthMeter("#directNewPassword", "#directStrengthBar", "#directStrengthText");
            bindStrengthMeter("#otpNewPassword", "#otpStrengthBar", "#otpStrengthText");

            // Auto-submit OTP when 6 digits entered
            $("#otpInput").on("input", function() {
                const v = $(this).val().trim();
                if (v.length === 6) {
                    $("#btnSubmitOtp").click();
                }
            });
        });

        /* UPDATE PHOTO */
        $("#profilePicForm").submit(function(e) {
            e.preventDefault();
            let formData = new FormData(this);

            $.ajax({
                url: "update_profile_backend.php",
                type: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(res) {
                    if (res.toLowerCase().includes("success")) {
                        showToast("Profile updated!");
                        setTimeout(() => location.reload(), 800);
                    } else showToast(res, "error");
                }
            });
        });

        /* UPDATE INFO */
        $("#updateInfoForm").submit(function(e) {
            e.preventDefault();
            $.post("update_profile_backend.php", $(this).serialize(), function(res) {
                if (res.toLowerCase().includes("success")) showToast("Information updated!");
                else showToast(res, "error");
            });
        });

        /* VERIFY CURRENT PASSWORD */
        $("#verifyPasswordForm").submit(function(e) {
            e.preventDefault();
            const curr = $("input[name='current_password']").val();

            $.post("verify_password.php", {
                current_password: curr
            }, function(res) {
                if (res === "OK") {
                    lastVerifiedPassword = curr;
                    showToast("Password verified.");
                    $("#directChangeSection").slideDown();
                    $("#otpChoiceSection").hide();
                    $("#otpSection").hide();
                } else {
                    showToast("Current password incorrect.", "error");
                    $("#directChangeSection").hide();
                    $("#otpChoiceSection").slideDown();
                }
            });
        });

        /* SEND OTP TO EMAIL (first time) */
        $("#btnOtpEmail").click(function() {
            $.post("send_otp.php", {
                email: "<?= htmlspecialchars($userdata['email'], ENT_QUOTES) ?>"
            }, function(res) {
                if (res === "OTP_SENT") {
                    showToast("OTP sent to your email.");
                    $("#otpSection").slideDown();
                    $("#btnResendOtp").show();
                    otpAttempts = 0;
                    $("#otpInput").prop("disabled", false).val("");
                    $("#btnSubmitOtp").prop("disabled", false).show();
                    $("#otpError").hide();

                    // Set expire time to 5 minutes from now (to match backend)
                    otpExpireAt = Date.now() + (5 * 60 * 1000);
                    startOtpExpiryCountdown();
                    startResendCooldown(30); // 30s cooldown for resend
                } else {
                    showToast(res, "error");
                }
            });
        });

        /* RESEND OTP */
        $("#btnResendOtp").click(function() {
            if ($("#btnResendOtp").prop("disabled")) return;

            $.post("send_otp.php", {
                email: "<?= htmlspecialchars($userdata['email'], ENT_QUOTES) ?>"
            }, function(res) {
                if (res === "OTP_SENT") {
                    showToast("New OTP sent to your email.");
                    otpAttempts = 0;
                    $("#otpInput").prop("disabled", false).val("");
                    $("#btnSubmitOtp").prop("disabled", false).show();
                    $("#otpError").hide();

                    otpExpireAt = Date.now() + (5 * 60 * 1000);
                    startOtpExpiryCountdown();
                    startResendCooldown(30);
                } else {
                    showToast(res, "error");
                }
            });
        });

        /* DIRECT PASSWORD SAVE */
        $("#directChangeForm").submit(function(e) {
            e.preventDefault();

            const newP = $("#directNewPassword").val();
            const confP = $("#directConfirmPassword").val();

            if (!newP || !confP) return showToast("Fill all fields", "error");
            if (newP !== confP) return showToast("Passwords do not match", "error");

            pendingChangeMode = "direct";
            pendingChangeData = {
                mode: "direct",
                current_password: lastVerifiedPassword,
                new_password: newP,
                confirm_password: confP
            };

            confirmModal.show();
        });

        /* STEP B — VERIFY OTP */
        $("#btnSubmitOtp").click(function() {

            const otp = $("#otpInput").val().trim();

            if (!otp) {
                $("#otpError").text("Please enter OTP").show();
                $("#otpInput").addClass("shake");
                setTimeout(() => $("#otpInput").removeClass("shake"), 300);
                return;
            }

            // If too many attempts already
            if (otpAttempts >= maxOtpAttempts) {
                $("#otpError").text("Too many invalid attempts. Please resend OTP.").show();
                $("#btnSubmitOtp").prop("disabled", true);
                return;
            }

            $.post("verify_otp.php", {
                otp: otp
            }, function(res) {

                if (res === "OTP_OK") {
                    $("#otpError").hide();
                    $("#otpInput").prop("disabled", true);
                    $("#btnSubmitOtp").hide();
                    $("#newPasswordArea").slideDown();
                    showToast("OTP verified! You may now set a new password.");
                } else {
                    otpAttempts++;
                    $("#otpError").text("Invalid OTP. Please try again.").show();
                    $("#otpInput").addClass("shake");
                    setTimeout(() => $("#otpInput").removeClass("shake"), 300);

                    if (otpAttempts >= maxOtpAttempts) {
                        $("#otpError").text("Too many invalid attempts. Please resend OTP.").show();
                        $("#btnSubmitOtp").prop("disabled", true);
                    }
                }
            });
        });

        /* STEP C — SUBMIT NEW PASSWORD AFTER OTP */
        $("#btnSubmitNewPassword").click(function() {

            const newP = $("#otpNewPassword").val();
            const confP = $("#otpConfirmPassword").val();

            if (!newP || !confP) {
                showToast("Please fill all fields.", "error");
                return;
            }
            if (newP !== confP) {
                showToast("Passwords do not match.", "error");
                return;
            }

            pendingChangeMode = "otp";
            pendingChangeData = {
                mode: "otp",
                otp: $("#otpInput").val().trim(),
                new_password: newP,
                confirm_password: confP,
                contact: "<?= htmlspecialchars($userdata['contact'], ENT_QUOTES) ?>",
                dob: "<?= htmlspecialchars($userdata['dob'], ENT_QUOTES) ?>",
                address: "<?= htmlspecialchars($userdata['address'], ENT_QUOTES) ?>"
            };

            confirmModal.show();
        });

        /* CONFIRMATION MODAL */
        $("#confirmChangeBtn").click(function() {

            $.post("change_password_backend.php", pendingChangeData, function(res) {
                if (res === "PASSWORD_CHANGED") {
                    showToast("Password updated!");
                    setTimeout(() => location.reload(), 1200);
                } else {
                    showToast(res, "error");
                }
            });

            pendingChangeMode = null;
            pendingChangeData = {};
            confirmModal.hide();
        });

        /* SHOW/HIDE PASSWORD ICON */
        $(document).on("click", ".toggle-pass", function() {
            let target = $(this).data("target");
            let input = $(target);

            if (input.attr("type") === "password") {
                input.attr("type", "text");
                $(this).text("🙈");
            } else {
                input.attr("type", "password");
                $(this).text("👁");
            }
        });
    </script>

</body>

</html>