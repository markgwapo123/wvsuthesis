<?php
$conn = new mysqli("localhost", "root", "", "supply_office");
session_start();

$user_id = $_SESSION['user_id'];

$sql = "
SELECT item_name, qty_requested, status, requested_at, processed_at
FROM requests
WHERE requester_user_id = $user_id
ORDER BY requested_at DESC
";

$result = $conn->query($sql);
?>

<table>
<tr>
  <th>Item</th>
  <th>Qty</th>
  <th>Status</th>
  <th>Requested</th>
  <th>Processed</th>
</tr>

<?php while($r = $result->fetch_assoc()): ?>
<tr>
  <td><?= $r['item_name'] ?></td>
  <td><?= $r['qty_requested'] ?></td>
  <td><?= $r['status'] ?></td>
  <td><?= $r['requested_at'] ?></td>
  <td><?= $r['processed_at'] ?? '-' ?></td>
</tr>
<?php endwhile; ?>
</table>
