<?php
session_start();
require_once __DIR__ . '/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$userId = (int)($_SESSION['user_id'] ?? 1);

// HANDLE SAVE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Match these names with the form fields below
    $theme         = $_POST['theme'] ?? 'light';
    $low           = isset($_POST['low_stock']) ? (int)$_POST['low_stock'] : 10;
    $exp_days      = isset($_POST['expiring_days']) ? (int)$_POST['expiring_days'] : 7;
    $auto_order    = $_POST['auto_order'] ?? 'manual';

    // Update only the columns that really exist in your table
    // user_settings columns (based on your schema):
    // theme, low_stock_threshold, auto_order, color_stock_ok, color_stock_low,
    // color_stock_out, expiring_days_threshold
    $upd = $conn->prepare("
        UPDATE user_settings
        SET theme = ?,
            low_stock_threshold = ?,
            auto_order = ?,
            expiring_days_threshold = ?
        WHERE user_id = ?
    ");
    if ($upd) {
        $upd->bind_param(
            "sisii",  // s = theme, i = low_stock_threshold, s = auto_order, i = exp_days, i = user_id
            $theme,
            $low,
            $auto_order,
            $exp_days,
            $userId
        );
        $upd->execute();
        $upd->close();
    }

    header("Location: settings.php?success=1");
    exit;
}

// LOAD SETTINGS
$res = $conn->query("SELECT * FROM user_settings WHERE user_id = {$userId} LIMIT 1");
$settings = $res && $res->num_rows > 0
    ? $res->fetch_assoc()
    : [
        'theme'                  => 'light',
        'low_stock_threshold'    => 10,
        'auto_order'             => 'manual',
        'color_stock_ok'         => '#28a745',
        'color_stock_low'        => '#ffc107',
        'color_stock_out'        => '#dc3545',
        'expiring_days_threshold'=> 7,
      ];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings</title>
    <link rel="stylesheet" href="admindasboard.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .main-content {
            padding: 20px;
        }

        .settings-wrapper {
            max-width: 900px;
            margin: 0 auto;
        }

        .settings-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .settings-header h2 {
            margin: 0;
        }

        .content-box {
            background: #ffffff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }

        .settings-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 20px;
            margin-top: 10px;
        }

        .settings-group {
            border: 1px solid #e3e6ea;
            border-radius: 10px;
            padding: 15px 18px;
        }

        .settings-group h3 {
            margin-top: 0;
            margin-bottom: 10px;
            font-size: 1rem;
            border-bottom: 1px solid #e3e6ea;
            padding-bottom: 6px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        input[type=number],
        select {
            padding: 6px 8px;
            width: 100%;
            margin-top: 4px;
            border-radius: 6px;
            border: 1px solid #cfd4da;
            box-sizing: border-box;
        }

        input[type=number]:focus,
        select:focus {
            outline: none;
            border-color: #007bff;
            box-shadow: 0 0 0 2px rgba(0,123,255,0.15);
        }

        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 0.9rem;
            border: 1px solid #c3e6cb;
        }

        .btn-save {
            margin-top: 20px;
            padding: 8px 18px;
            border-radius: 20px;
            background: #007bff;
            border: none;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
        }

        .btn-save:hover {
            background: #0069d9;
        }

        .note {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 4px;
        }
    </style>
</head>
<body class="<?= $settings['theme'] == 'dark' ? 'dark-mode' : '' ?>">

    <div class="dashboard">
        <?php include 'sidebar.php'; ?>

        <main class="main-content">
            <div class="settings-wrapper">
                <div class="settings-header">
                    <h2>User Settings</h2>
                </div>

                <div class="content-box">
                    <?php if (isset($_GET['success'])): ?>
                        <div class="success">Settings saved successfully.</div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="settings-grid">

                            <!-- Theme & Mode -->
                            <div class="settings-group">
                                <h3>Display</h3>

                                <label>Theme Mode</label>
                                <select name="theme">
                                    <option value="light" <?= $settings['theme'] === 'light' ? 'selected' : '' ?>>
                                        Light
                                    </option>
                                    <option value="dark" <?= $settings['theme'] === 'dark' ? 'selected' : '' ?>>
                                        Dark
                                    </option>
                                </select>
                                <p class="note">Switch between light and dark mode for the dashboard UI.</p>
                            </div>

                            <!-- Stock & Expiry -->
                            <div class="settings-group">
                                <h3>Inventory Alerts</h3>

                                <label>Low Stock Alert Threshold</label>
                                <input
                                    type="number"
                                    name="low_stock"
                                    min="1"
                                    value="<?= (int)$settings['low_stock_threshold'] ?>">

                                <label>Expiring Item Alert (days before)</label>
                                <input
                                    type="number"
                                    name="expiring_days"
                                    min="1"
                                    value="<?= (int)$settings['expiring_days_threshold'] ?>">

                                <p class="note">
                                    Items below the stock threshold or nearing expiration can be highlighted in reports.
                                </p>
                            </div>

                            <!-- Order Mode -->
                            <div class="settings-group">
                                <h3>Order Request Mode</h3>

                                <label>Order Mode</label>
                                <select name="auto_order">
                                    <option value="manual" <?= $settings['auto_order'] === 'manual' ? 'selected' : '' ?>>
                                        Manual
                                    </option>
                                    <option value="automatic" <?= $settings['auto_order'] === 'automatic' ? 'selected' : '' ?>>
                                        Automatic
                                    </option>
                                </select>
                                <p class="note">
                                    Manual: you review and create order requests yourself.<br>
                                    Automatic: the system can suggest or auto-generate requests when stock is low.
                                </p>
                            </div>

                        </div>

                        <button type="submit" class="btn-save">Save Settings</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <script src="admindashboard.js" defer></script>
</body>
</html>
