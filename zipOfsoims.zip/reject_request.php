<?php
session_start();
require_once __DIR__ . "/db_connect.php";

if (($_SESSION['role'] ?? '') !== 'admin') {
    exit("Unauthorized");
}

$request_id = (int)$_GET['id'];

$conn->query("
    UPDATE requests
    SET status = 'Rejected',
        processed_by = '{$_SESSION['fullname']}',
        processed_at = NOW()
    WHERE id = $request_id
");

header("Location: admin_requests.php");
exit();
