<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Scan Item for Disposal</title>

<!-- Google Font -->
<link href="assets\bootstrap-5.3.2-dist\css\bootstrap.css" rel="stylesheet">

<style>
    body {
        margin: 0;
        padding: 0;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background: linear-gradient(135deg, #1e3c72, #2a5298);
        font-family: 'Poppins', sans-serif;
    }

    .scan-container {
        background: #ffffff;
        width: 420px;
        padding: 40px 35px;
        border-radius: 16px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        text-align: center;
        animation: fadeIn 0.4s ease;
    }

    h2 {
        margin-bottom: 25px;
        font-weight: 600;
        color: #1e3c72;
        letter-spacing: 0.5px;
    }

    label {
        display: block;
        text-align: left;
        font-size: 14px;
        font-weight: 500;
        margin-bottom: 8px;
        color: #333;
    }

    input[type="text"] {
        width: 100%;
        padding: 14px 12px;
        font-size: 16px;
        border: 1px solid #cfd8dc;
        border-radius: 10px;
        outline: none;
        transition: all 0.3s ease;
        background: #fafafa;
    }

    input[type="text"]:focus {
        border-color: #1e88e5;
        box-shadow: 0 0 6px rgba(30, 136, 229, 0.3);
        background: #ffffff;
    }

    button {
        margin-top: 18px;
        width: 100%;
        padding: 14px;
        font-size: 16px;
        font-weight: 600;
        color: white;
        background: #1e88e5;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: 0.3s ease;
    }

    button:hover {
        background: #1565c0;
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(21,101,192,0.25);
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(15px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

</style>
</head>

<body>

<div class="scan-container">
    <h2>Dispose Item</h2>

    <form action="disposed_form.php" method="POST">
        <label>Scan Barcode:</label>
        <input type="text" name="barcode" placeholder="Scan or enter barcode..." required autofocus>

        <button type="submit">Search Item</button>
    </form>
</div>

</body>
</html>
