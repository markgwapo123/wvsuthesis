<?php
// Only DB + session, no auth.php
require_once __DIR__ . '/db_connect.php';

// Simple auth: only allow logged-in end_user
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'end_user') {
    header("Location: index.php?error=Unauthorized");
    exit();
}

$user_id    = $_SESSION['user_id'];
$department = $_SESSION['department'] ?? null;

if (!$department) {
    exit('No department assigned to this End User. Contact the administrator.');
}

// Safe default image (place an actual file in your assets folder)
$defaultImage = "assets/img/default_profile.png";

// Use user's profile image if it exists, else fallback
$profileImage = (!empty($_SESSION['profile_img']))
    ? htmlspecialchars($_SESSION['profile_img'], ENT_QUOTES)
    : $defaultImage;

// Inventory for this department
$stmtInv = $conn->prepare("SELECT * FROM inventory WHERE department = ?");
$stmtInv->bind_param("s", $department);
$stmtInv->execute();
$inventory_result = $stmtInv->get_result();

// Pending orders for this department
$stmtReq = $conn->prepare("SELECT * FROM orders WHERE department = ? AND status = 'Pending'");
$stmtReq->bind_param("s", $department);
$stmtReq->execute();
$pending_orders_result = $stmtReq->get_result();

// Pending request for this department
$stmtReq = $conn->prepare("SELECT * FROM requests WHERE requester_department = ? AND status = 'Pending'");
$stmtReq->bind_param("s", $department);
$stmtReq->execute();
$pending_requests_result = $stmtReq->get_result();

// Low stock (example: < 5)
$stmtLow = $conn->prepare("SELECT * FROM inventory WHERE department = ? AND quantity < 5 AND quantity > 0");
$stmtLow->bind_param("s", $department);
$stmtLow->execute();
$low_stock_result = $stmtLow->get_result();

// Out of stock
$stmtOut = $conn->prepare("SELECT * FROM inventory WHERE department = ? AND quantity = 0");
$stmtOut->bind_param("s", $department);
$stmtOut->execute();
$out_of_stock_result = $stmtOut->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>End User Dashboard</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #0044cc;
            color: white;
            padding: 16px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            margin: 0;
            font-size: 20px;
        }

        header nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            gap: 16px;
            align-items: center;
        }

        header nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
        }

        .profile-avatar-wrapper {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .profile-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
            display: block;
        }

        .page-wrap {
            padding: 24px;
        }

        .page-title {
            margin: 0 0 8px;
            font-size: 22px;
        }

        .subtitle {
            margin: 0 0 24px;
            color: #555;
            font-size: 14px;
        }

        .status-cards {
            display: flex;
            gap: 16px;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }

        .card {
            background-color: #fff;
            padding: 16px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            min-width: 200px;
            flex: 1;
        }

        .card h2 {
            margin: 0 0 4px;
            font-size: 16px;
        }

        .card p {
            margin: 0;
            font-size: 14px;
            color: #333;
        }

        .inventory {
            background: #fff;
            border-radius: 8px;
            padding: 16px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .inventory h2 {
            margin-top: 0;
            font-size: 18px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
            font-size: 14px;
        }

        th,
        td {
            padding: 10px 8px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        th {
            background-color: #f4f7fc;
            font-weight: 600;
        }

        .status {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 12px;
        }

        .status.in-stock {
            background-color: #e2f7e9;
            color: #1b8a3b;
        }

        .status.low-stock {
            background-color: #fff5d6;
            color: #a97810;
        }

        .status.out-of-stock {
            background-color: #fde2e2;
            color: #b62323;
        }

        .btn {
            display: inline-block;
            background-color: #0044cc;
            color: white;
            padding: 6px 14px;
            text-decoration: none;
            border-radius: 4px;
            width: 1.5cm;
            font-size: 14px;
        }

        .btn:hover {
            background-color: #0033a0;
        }

        .btn.disabled {
            background-color: #ccc;
            padding: 6px 14px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 13px;
            cursor: not-allowed;
        }

        footer {
            text-align: center;
            padding: 12px 0;
            background-color: #222;
            color: white;
            margin-top: 24px;
            font-size: 12px;
        }

        .logout-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        }

        .logout-box {
            background: #fff;
            padding: 20px 25px;
            border-radius: 10px;
            text-align: center;
            max-width: 280px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .logout-actions {
            margin-top: 15px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .btn-yes {
            background: #e74a3b;
            color: white;
            border: none;
            padding: 8px 18px;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-no {
            background: #36b9cc;
            color: white;
            border: none;
            padding: 8px 18px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
    <!-- Logout Confirmation Modal -->
    <div id="logoutConfirm" class="logout-overlay" style="display:none;">
        <div class="logout-box">
            <p>Are you sure you want to log out?</p>
            <div class="logout-actions">
                <button id="confirmLogout" class="btn-yes">Yes</button>
                <button id="cancelLogout" class="btn-no">No</button>
            </div>
        </div>
    </div>
    <script>
document.getElementById("logoutBtn").onclick = function (e) {
    e.preventDefault();
    document.getElementById("logoutConfirm").style.display = "flex";
};

document.getElementById("cancelLogout").onclick = function () {
    document.getElementById("logoutConfirm").style.display = "none";
};

document.getElementById("confirmLogout").onclick = async function () {
    await fetch("logout.php", { method: "POST" });
    window.location.href = "index.php";
};
</script>

</head>

<body>
<header>
    <h1>SOIMS | End User</h1>
    <nav>
        <ul>
            <li><strong><?= htmlspecialchars($_SESSION['fullname'] ?? 'End User'); ?></strong></li>

            <li>
                <div class="profile-avatar-wrapper" onclick="window.location.href='manage_account.php'">
                    <img src="<?= $profileImage ?>"
                         class="profile-avatar"
                         onerror="this.src='<?= $defaultImage ?>';">
                </div>
            </li>

            <li><a href="#" id="logoutBtn">Logout</a></li>
        </ul>
    </nav>
</header>

<!-- =======================================
       LOGOUT CONFIRM MODAL (INSIDE BODY NOW)
=========================================== -->
<div id="logoutConfirm" class="logout-overlay" style="display:none;">
    <div class="logout-box">
        <p>Are you sure you want to log out?</p>
        <div class="logout-actions">
            <button id="confirmLogout" class="btn-yes">Yes</button>
            <button id="cancelLogout" class="btn-no">No</button>
        </div>
    </div>
</div>

<script>
// Open modal
document.getElementById("logoutBtn").onclick = function(e) {
    e.preventDefault();
    document.getElementById("logoutConfirm").style.display = "flex";
};

// Cancel modal
document.getElementById("cancelLogout").onclick = function() {
    document.getElementById("logoutConfirm").style.display = "none";
};

// Confirm logout
document.getElementById("confirmLogout").onclick = async function () {
    await fetch("logout.php", { method: "POST" });
    window.location.href = "index.php";
};
</script>


    <div class="page-wrap">
        <h2 class="page-title"><?= htmlspecialchars($department); ?> Department</h2>
        <p class="subtitle">You are viewing stocks and requests for your assigned department only.</p>

        <div class="status-cards">
             <div class="card">
                <h2>Pending Orders</h2>
                <p><?= $pending_orders_result->num_rows; ?> pending order(s)</p>
            </div>
            <div class="card">
                <h2>Pending Requests</h2>
                <p><?= $pending_requests_result->num_rows; ?> pending request(s)</p>
            </div>
            <div class="card">
                <h2>Low Stock</h2>
                <p><?= $low_stock_result->num_rows; ?> item(s) low on stock</p>
            </div>
            <div class="card">
                <h2>Out of Stock</h2>
                <p><?= $out_of_stock_result->num_rows; ?> item(s) out of stock</p>
            </div>
        </div>

        <div class="inventory">
            <h2>Inventory for <?= htmlspecialchars($department); ?> Department</h2>
            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Qty</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $inventory_result->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <?php
                                $itemName = $item['item_name']
                                    ?? $item['name']
                                    ?? $item['item']
                                    ?? $item['description']
                                    ?? '[Unnamed Item]';
                                echo htmlspecialchars($itemName);
                                ?>
                            </td>

                            <td><?= (int)$item['quantity'] ?></td>

                            <td>
                                <?php
                                $qty = (int)$item['quantity'];
                                if ($qty === 0) {
                                    echo '<span class="status out-of-stock">Out of Stock</span>';
                                } elseif ($qty < 5) {
                                    echo '<span class="status low-stock">Low Stock</span>';
                                } else {
                                    echo '<span class="status in-stock">In Stock</span>';
                                }
                                ?>
                            </td>

                            <td>
                                <?php
                                $itemId = $item['inventory_id'];

                                if ($qty > 0 && $itemId): ?>
                                    <a href="request_stock.php?inventory_id=<?= $item['inventory_id'] ?>" class="btn">Request</a>
                                <?php else: ?>
                                    <span class="btn disabled">Unavailable</span>
                                <?php endif; ?>
                                <a href="restock.php?item_id=<?= htmlspecialchars($itemId) ?>" class="btn"> Restock</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <footer>
        &copy; <?= date('Y'); ?> SOIMS. All rights reserved.
    </footer>

</body>

</html>