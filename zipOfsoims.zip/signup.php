<?php
require_once __DIR__ . '/db_connect.php';

// Only admin can create new accounts
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php?error=Unauthorized access");
    exit();
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName  = trim($_POST['firstName']);
    $middleName = trim($_POST['middleName']);
    $lastName   = trim($_POST['lastName']);
    $dob        = $_POST['dob'];
    $contact    = trim($_POST['contact']);
    $address    = trim($_POST['address']);
    $email      = trim($_POST['email']);
    $password   = $_POST['password'];
    $role       = $_POST['role'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        header("Location: signup.php?error=Invalid email format");
        exit();
    }

    // Hash password securely
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL insert
    $stmt = $conn->prepare("
        INSERT INTO users 
        (first_name, middle_name, last_name, dob, contact, address, email, password, role, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param("sssssssss", $firstName, $middleName, $lastName, $dob, $contact, $address, $email, $hashedPassword, $role);

    if ($stmt->execute()) {
        header("Location: signup.php?success=1");
        exit();
    } else {
        header("Location: signup.php?error=Database error: " . urlencode($stmt->error));
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create User Account</title>
  <link rel="stylesheet" href="signup.css">
</head>
<body class="<?= $settings['theme']=='dark' ? 'dark-mode' : '' ?>">
  <div class="container">
    <div class="header"><h1>Create Account</h1></div>
    <?php if (isset($_GET['success'])): ?>
      <div class="success-message">Account created successfully!</div>
    <?php endif; ?>
    <form method="POST" action="signup_process.php">
      <div class="form-group"><label>First Name</label><input type="text" name="firstName" required></div>
      <div class="form-group"><label>Middle Name</label><input type="text" name="middleName" required></div>
      <div class="form-group"><label>Last Name</label><input type="text" name="lastName" required></div>
      <div class="form-group"><label>Date of Birth</label><input type="date" name="dob" required max="<?= date('Y-m-d') ?>"></div>
      <div class="form-group"><label>Contact</label><input type="tel" name="contact" required></div>
      <div class="form-group"><label>Address</label><textarea name="address" required></textarea></div>
      <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
      <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
      <div class="form-group">
        <label>Role</label>
        <select name="role" required>
          <option value="subadmin">Sub Admin</option>
          <option value="procurement">Procurement Officer</option>
        </select>
      </div>
      <button type="submit">Create New User</button>
    </form>
    <a href="users.php">⬅ Back User management</a>
  </div>
</body>
</html>
