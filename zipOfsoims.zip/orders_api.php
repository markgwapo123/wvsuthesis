<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? '';

if ($action === 'get_orders') {
  $res = $conn->query("SELECT * FROM orders ORDER BY order_id DESC");
  $orders = [];
  while ($row = $res->fetch_assoc()) $orders[] = $row;
  echo json_encode(['data' => $orders]);
  exit;
}

if ($action === 'update_status') {
  $id = (int)$_POST['order_id'];
  $status = $conn->real_escape_string($_POST['status']);
  $conn->query("UPDATE orders SET status='$status' WHERE order_id=$id");
  echo json_encode(['success' => true]);
  exit;
}

if ($action === 'delete') {
  $id = (int)$_POST['order_id'];
  $row = $conn->query("SELECT * FROM orders WHERE order_id=$id")->fetch_assoc();
  if ($row) {
    $json = $conn->real_escape_string(json_encode($row));
    $deleted_by = 1; // Replace with $_SESSION['user_id'] if available
    $conn->query("INSERT INTO archive_all (table_name, record_id, data, deleted_by, deleted_at, purge_at)
                  VALUES ('orders', $id, '$json', $deleted_by, NOW(), DATE_ADD(NOW(), INTERVAL 15 DAY))");
    $conn->query("DELETE FROM orders WHERE order_id=$id");
  }
  echo json_encode(['success' => true]);
  exit;
}
