<?php 
require_once "db_connect.php";

/* Pagination */
$page = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$where = [];

/* =======================
   LIVE SEARCH
======================= */
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(item_name LIKE '%$s%' 
                OR department LIKE '%$s%' 
                OR requestor_name LIKE '%$s%' 
                OR receiver LIKE '%$s%' 
                OR reason LIKE '%$s%')";
}

/* =======================
   FILTERS
======================= */
$filters = [
    "department"        => "department",
    "requestor_name"    => "requestor_name",
    "receiver"          => "receiver"
];

foreach ($filters as $key => $col) {
    if (!empty($_POST[$key])) {
        $v = $conn->real_escape_string($_POST[$key]);
        $where[] = "$col LIKE '%$v%'";
    }
}

$whereSQL = empty($where) ? "" : "WHERE " . implode(" AND ", $where);


/* =======================
   COUNT TOTAL
======================= */
$countRes = $conn->query("
    SELECT COUNT(*) AS total FROM disposals
    $whereSQL
");
$totalRows = $countRes->fetch_assoc()['total'];
$totalPages = max(1, ceil($totalRows / $limit));


/* =======================
   MAIN QUERY
======================= */
$sql = "
SELECT * FROM disposals
$whereSQL
ORDER BY disposal_date DESC
LIMIT $limit OFFSET $offset
";

$res = $conn->query($sql);


/* =======================
   OUTPUT TABLE
======================= */

echo "
<table class='table'>
<thead>
<tr>
  <th>ID</th>
  <th>Item Name</th>
  <th>Department</th>
  <th>Requestor</th>
  <th>Receiver</th>
  <th>Reason</th>
  <th>Processed By</th>
  <th>Disposal Date</th>
</tr>
</thead>
<tbody>
";

if ($res && $res->num_rows > 0) {
    while ($r = $res->fetch_assoc()) {

        /* COLOR ROW CLASSES */
        $cls = "";
        // Add any logic you need for row classes here (e.g., based on item condition)
        
        echo "
        <tr class='$cls'>
            <td>{$r['disposal_id']}</td>
            <td>".htmlspecialchars($r['item_name'])."</td>
            <td>".htmlspecialchars($r['department'])."</td>
            <td>".htmlspecialchars($r['requestor_name'])."</td>
            <td>".htmlspecialchars($r['receiver'])."</td>
            <td>".htmlspecialchars($r['reason'])."</td>
            <td>".htmlspecialchars($r['processed_by'])."</td>
            <td>{$r['disposal_date']}</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='8'>No records found.</td></tr>";
}

echo "</tbody></table>";

/* Pagination Output */
echo "<div class='pagination'>";
if ($page > 1) echo "<span class='page-link' data-page='".($page-1)."'>Previous</span>";

for ($i = 1; $i <= $totalPages; $i++) {
    $active = ($i == $page) ? "active" : "";
    echo "<span class='page-link $active' data-page='$i'>$i</span>";
}

if ($page < $totalPages) echo "<span class='page-link' data-page='".($page+1)."'>Next</span>";
echo "</div>";
?>
