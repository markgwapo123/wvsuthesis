<?php
session_start();
require_once 'db_connect.php';

// Load theme
$settingsQuery = $conn->query("SELECT * FROM user_settings WHERE user_id = 1 LIMIT 1");
$settings = ($settingsQuery && $settingsQuery->num_rows > 0)
  ? $settingsQuery->fetch_assoc()
  : ['theme' => 'light'];

// If already logged in, redirect by role 
// BUT do NOT auto-redirect when the user was sent here due to "Unauthorized"
if (isset($_SESSION['role']) && (!isset($_GET['error']) || $_GET['error'] !== 'Unauthorized')) {

    if ($_SESSION['role'] === 'admin') {
        header("Location: admindashboard.php");
        exit();

    } elseif ($_SESSION['role'] === 'procurement') {
        header("Location: procurementdashboard.php");
        exit();

    } elseif ($_SESSION['role'] === 'subadmin') { 
        header("Location: userdashboard.php");
        exit();

    } elseif ($_SESSION['role'] === 'end_user') {
        header("Location: endUserDashboard.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SOIMS Login</title>
  <link rel="stylesheet" href="style.css">

  <style>
    .password-wrapper { position: relative; width: 100%; }
    .toggle-password {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      font-size: 18px;
      color: #444;
      user-select: none;
    }
    .forgot {
      margin-top: 10px;
      text-align: right;
    }
    .forgot a {
      font-size: 13px;
      color: #007bff;
      text-decoration: none;
    }
    .forgot a:hover {
      text-decoration: underline;
    }
  </style>
</head>

<body class="<?= $settings['theme']=='dark' ? 'dark-mode' : '' ?>">
  <div class="container">
    <div class="left-panel">
      <div class="logo">
        <h1>SOIMS</h1>
        <p>Supply Office Inventory<br>Management System</p>
      </div>
    </div>

    <div class="right-panel">
      <div class="login-card">
        <h3>Welcome to <br><strong>SOIMS</strong></h3>
        <h4 class="admin-label"> Log in to <b>Your Account</b></h4>

        <?php if (isset($_GET['error'])): ?>
          <p style="color:red;"><?= htmlspecialchars($_GET['error']) ?></p>
        <?php endif; ?>

        <form method="POST" action="login_process.php">
          <input type="hidden" name="role" value="admin">

          <div class="input-group">
            <span class="icon">👤</span>
            <input type="email" name="email" placeholder="Email" required>
          </div>

          <div class="input-group password-wrapper">
            <span class="icon">🔒</span>
            <input type="password" id="passwordField" name="password" placeholder="Password" required>
            <span class="toggle-password" id="togglePassword">👁</span>
          </div>

          <div class="forgot">
            <a href="forgot_password.php">Forgot Password?</a>
          </div>

          <button type="submit" class="login-btn">Log In</button>
        </form>

      </div>
    </div>
  </div>

  <script>
    const passwordField = document.getElementById("passwordField");
    const togglePassword = document.getElementById("togglePassword");

    togglePassword.addEventListener("click", () => {
      const type = passwordField.getAttribute("type") === "password" ? "text" : "password";
      passwordField.setAttribute("type", type);
      togglePassword.textContent = type === "password" ? "👁" : "🙈";
    });
  </script>

</body>
</html>
