<?php
require_once "auth.php";
require_once "db_connect.php";

$user = current_user();
if (!$user) {
    exit("Unauthorized access.");
}

$user_id = $user['id'];

// ==============================
// HANDLE PROFILE IMAGE UPLOAD
// ==============================
if (!empty($_FILES['profile_img']['name'])) {

    $targetDir = "uploads/profile/";
    if (!file_exists($targetDir)) mkdir($targetDir, 0777, true);

    $fileName   = $user_id . "_" . time() . "_" . basename($_FILES["profile_img"]["name"]);
    $targetFile = $targetDir . $fileName;

    $allowed = ["jpg","jpeg","png"];
    $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) {
        exit("Only JPG and PNG are allowed.");
    }

    if (move_uploaded_file($_FILES["profile_img"]["tmp_name"], $targetFile)) {

        $stmt = $conn->prepare("UPDATE users SET profile_img = ? WHERE id = ?");
        $stmt->bind_param("si", $targetFile, $user_id);
        $stmt->execute();

        // optional activity log
        if (function_exists('log_activity')) {
            log_activity($user_id, "Updated profile picture", "Account", "Success", $conn);
        }

        exit("success: Profile picture updated successfully!");
    } else {
        exit("Failed to upload image.");
    }
}

// ==============================
// HANDLE INFORMATION UPDATE
// ==============================
if (!empty($_POST['first_name'])) {

    $first   = $conn->real_escape_string($_POST['first_name']);
    $middle  = $conn->real_escape_string($_POST['middle_name'] ?? "");
    $last    = $conn->real_escape_string($_POST['last_name']);
    $dob     = $conn->real_escape_string($_POST['dob'] ?? null);
    $contact = $conn->real_escape_string($_POST['contact']);
    $email   = $conn->real_escape_string($_POST['email']);

    // Validate email is not used by another user
    $emailCheck = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $emailCheck->bind_param("si", $email, $user_id);
    $emailCheck->execute();
    $emailCheckRes = $emailCheck->get_result();

    if ($emailCheckRes->num_rows > 0) {
        exit("Email already in use by another account.");
    }

    $stmt = $conn->prepare("
        UPDATE users 
        SET first_name=?, middle_name=?, last_name=?, dob=?, contact=?, email=? 
        WHERE id=?
    ");
    $stmt->bind_param("ssssssi", $first, $middle, $last, $dob, $contact, $email, $user_id);
    $stmt->execute();

    if (function_exists('log_activity')) {
        log_activity($user_id, "Updated account information", "Account", "Success", $conn);
    }

    exit("success: Account information updated.");
}

exit("No changes detected.");
