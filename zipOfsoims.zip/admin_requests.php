<?php
session_start();
require_once __DIR__ . "/db_connect.php";

/* ======================
   ADMIN AUTH CHECK
====================== */
if (($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: index.php?error=Unauthorized");
    exit();
}

/* ======================
   FETCH REQUESTS
====================== */
$sql = "
    SELECT
        request_id,
        requester_name,
        requester_department,
        item_name,
        unit,
        qty_requested,
        remarks,
        status,
        requested_at
    FROM requests
    ORDER BY requested_at DESC
";

$requests = $conn->query($sql);
if (!$requests) {
    die("Database Error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin | Pending Requests</title>

<style>
body {
    font-family: Poppins, Arial, sans-serif;
    background: #f4f7fc;
    padding: 30px;
}

h2 {
    margin-bottom: 15px;
    color: #003366;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: #ffffff;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 6px 20px rgba(0,0,0,0.08);
}

th {
    background: #003366;
    color: white;
    text-transform: uppercase;
    font-size: 13px;
    padding: 14px;
}

td {
    padding: 12px;
    border-bottom: 1px solid #e6e6e6;
    font-size: 14px;
}

tr:hover {
    background: #f0f6ff;
}

a {
    text-decoration: none;
    font-weight: 600;
    padding: 6px 12px;
    border-radius: 5px;
    font-size: 13px;
    display: inline-block;
}

.approve {
    background: #28a745;
    color: white;
}

.reject {
    background: #dc3545;
    color: white;
}

a:hover {
    opacity: 0.85;
}

.status-badge {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}

.status-Pending {
    background: #fff3cd;
    color: #856404;
}

.status-Approved {
    background: #d4edda;
    color: #155724;
}

.status-Rejected {
    background: #f8d7da;
    color: #721c24;
}

.empty-row {
    text-align: center;
    font-weight: bold;
    padding: 20px;
    color: #777;
}
</style>
</head>

<body>

<h2>Pending Requests</h2>

<table>
<thead>
<tr>
    <th>Requester</th>
    <th>Department</th>
    <th>Item</th>
    <th>Quantity</th>
    <th>Unit</th>
    <th>Status</th>
    <th>Requested At</th>
    <th>Action</th>
</tr>
</thead>

<tbody>
<?php if ($requests->num_rows > 0): ?>
    <?php while ($r = $requests->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($r['requester_name']) ?></td>
            <td><?= htmlspecialchars($r['requester_department']) ?></td>
            <td><?= htmlspecialchars($r['item_name']) ?></td>
            <td><?= (int)$r['qty_requested'] ?></td>
            <td><?= htmlspecialchars($r['unit']) ?></td>
            <td>
                <span class="status-badge status-<?= htmlspecialchars($r['status']) ?>">
                    <?= htmlspecialchars($r['status']) ?>
                </span>
            </td>
            <td><?= htmlspecialchars($r['requested_at']) ?></td>
            <td>
                <?php if ($r['status'] === 'Pending'): ?>
                    <a class="approve" href="approve_request.php?request_id=<?= $r['request_id'] ?>">Approve</a>
                    <a class="reject" href="reject_request.php?request_id=<?= $r['request_id'] ?>">Reject</a>
                <?php else: ?>
                    —
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr>
        <td colspan="8" class="empty-row">No requests found</td>
    </tr>
<?php endif; ?>
</tbody>
</table>

</body>
</html>
