<?php
require_once "db_connect.php";

$today = date("Y-m-d");

/* Pagination */
$page = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$where = [];

/* Live Search */
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(name LIKE '%$s%' OR category LIKE '%$s%' OR department LIKE '%$s%')";
}

/* Filters */
$filters = [
    "category" => "category",
    "status_label" => "status_label",
    "condition_label" => "condition_label"
];

foreach ($filters as $key => $col) {
    if (!empty($_POST[$key])) {
        $v = $conn->real_escape_string($_POST[$key]);
        $where[] = "$col LIKE '%$v%'";
    }
}

/* Days filter */
if (!empty($_POST["days"])) {
    $days = intval($_POST["days"]);
    $where[] = "DATEDIFF(expiration_date, CURDATE()) <= $days";
}

/* Must have expiration date */
$where[] = "expiration_date IS NOT NULL";

$whereSQL = "WHERE " . implode(" AND ", $where);

/* Count rows */
$count = $conn->query("SELECT COUNT(*) AS total FROM inventory $whereSQL")->fetch_assoc()['total'];
$totalPages = max(1, ceil($count / $limit));

/* Query */
$sql = "
SELECT 
    inventory_id,
    name,
    category,
    expiration_date,
    DATEDIFF(expiration_date, CURDATE()) AS days_left,
    condition_label,
    status_label
FROM inventory
WHERE DATEDIFF(expiration_date, CURDATE()) = 30
ORDER BY expiration_date ASC
LIMIT $limit OFFSET $offset
";

$res = $conn->query($sql);

/* Output table */
echo "
<table class='table'>
<thead>
<tr>
  <th>ID</th>
  <th>Name</th>
  <th>Category</th>
  <th>Expiration Date</th>
  <th>Days Left</th>
  <th>Status</th>
</tr>
</thead>
<tbody>
";

if ($res && $res->num_rows > 0) {
    while ($r = $res->fetch_assoc()) {

        $days = intval($r["days_left"]);
        $cls = "";

        if ($days < 0) $cls = "expired";       // expired
        elseif ($days <= 30) $cls = "soon";   // expiring soon

        echo "
        <tr class='$cls'>
            <td>{$r['inventory_id']}</td>
            <td>".htmlspecialchars($r['name'])."</td>
            <td>".htmlspecialchars($r['category'])."</td>
            <td>{$r['expiration_date']}</td>
            <td>$days</td>
            <td>{$r['condition_label']}</td>
        </tr>";
    }

} else {
    echo "<tr><td colspan='6'>No expiring items found.</td></tr>";
}

echo "</tbody></table>";

/* Pagination */
echo "<div class='pagination'>";
if ($page > 1) echo "<span class='page-link' data-page='".($page-1)."'>Previous</span>";

for ($i=1; $i <= $totalPages; $i++){
    $a = ($i == $page) ? "active" : "";
    echo "<span class='page-link $a' data-page='$i'>$i</span>";
}

if ($page < $totalPages) echo "<span class='page-link' data-page='".($page+1)."'>Next</span>";
echo "</div>";
