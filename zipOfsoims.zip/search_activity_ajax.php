<?php
require_once 'db_connect.php';

$perPage = 10; // ★ how many logs per page
$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
$offset = ($page - 1) * $perPage;

$where = [];

// Filters
if (!empty($_POST['uid']))  $where[] = "user_id = " . intval($_POST['uid']);
if (!empty($_POST['module'])) $where[] = "module LIKE '%" . $conn->real_escape_string($_POST['module']) . "%'";
if (!empty($_POST['action'])) $where[] = "action LIKE '%" . $conn->real_escape_string($_POST['action']) . "%'";
if (!empty($_POST['device'])) $where[] = "device LIKE '%" . $conn->real_escape_string($_POST['device']) . "%'";
if (!empty($_POST['from'])) $where[] = "DATE(created_at) >= '" . $conn->real_escape_string($_POST['from']) . "'";
if (!empty($_POST['to']))   $where[] = "DATE(created_at) <= '" . $conn->real_escape_string($_POST['to']) . "'";

// Live search
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(action LIKE '%$s%' OR module LIKE '%$s%' OR device LIKE '%$s%' OR ip_address LIKE '%$s%')";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

// Count total rows
$countQuery = $conn->query("SELECT COUNT(*) AS total FROM activity_logs $whereSQL");
$total = $countQuery->fetch_assoc()['total'];
$totalPages = ceil($total / $perPage);

// Fetch paginated rows
$query = "
    SELECT * FROM activity_logs
    $whereSQL
    ORDER BY created_at DESC
    LIMIT $perPage OFFSET $offset
";
$res = $conn->query($query);
?>

<table id='activityLogsTable'>
  <thead>
    <tr>
      <th class='sortable'>Log ID</th>
      <th class='sortable'>User</th>
      <th class='sortable'>Action</th>
      <th class='sortable'>Module</th>
      <th class='sortable'>Status</th>
      <th class='sortable'>IP Address</th>
      <th class='sortable'>Device</th>
      <th class='sortable'>Date/Time</th>
      <th>Details</th>
    </tr>
  </thead>
  <tbody>

<?php
if ($res->num_rows == 0) {
    echo "<tr><td colspan='9'>No logs found.</td></tr>";
} else {
    while ($row = $res->fetch_assoc()) {

        $logId = $row['log_id'];
        $userId = $row['user_id'];
        $action = htmlspecialchars($row['action']);
        $module = htmlspecialchars($row['module']);
        $status = htmlspecialchars($row['status']);
        $ip = htmlspecialchars($row['ip_address']);
        $device = htmlspecialchars($row['device']);
        $createdAt = htmlspecialchars($row['created_at']);

        echo "
        <tr>
          <td>$logId</td>
          <td><a href='view_record.php?type=user&id=$userId' target='_blank'>$userId</a></td>
          <td>$action</td>
          <td>$module</td>
          <td>$status</td>
          <td>$ip</td>
          <td>$device</td>
          <td>$createdAt</td>
          <td>
            <button 
              class='view-details-btn'
              data-log-id='$logId'
              data-user-id='$userId'
              data-action='$action'
              data-module='$module'
              data-status='$status'
              data-ip='$ip'
              data-device='" . htmlspecialchars($row['device'], ENT_QUOTES) . "'
              data-created-at='$createdAt'>
              View
            </button>
          </td>
        </tr>";
    }
}
?>
</tbody>
</table>

<!-- PAGINATION BUTTONS -->
<div style="margin-top:10px; text-align:center;">
<?php if ($page > 1): ?>
  <button class="pagination-btn" data-page="<?= $page - 1 ?>">⟵ Previous</button>
<?php endif; ?>

<?php
for ($i = 1; $i <= $totalPages; $i++) {
    $active = ($i == $page) ? "style='font-weight:bold;'" : "";
    echo "<button class='pagination-btn' data-page='$i' $active>$i</button>";
}
?>

<?php if ($page < $totalPages): ?>
  <button class="pagination-btn" data-page="<?= $page + 1 ?>">Next ⟶</button>
<?php endif; ?>
</div>
