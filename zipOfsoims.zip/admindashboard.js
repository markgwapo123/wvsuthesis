// ==============================
// Chart.js Pie Chart
// ==============================
document.addEventListener("DOMContentLoaded", () => {
  const chartCanvas = document.getElementById("pieChart");
  if (chartCanvas) {
    const ctx = chartCanvas.getContext("2d");
    new Chart(ctx, {
      type: "pie",
      data: {
        labels: ["Stationary", "Cleaning", "Tech", "Misc"],
        datasets: [{
          data: [147, 90, 126, 108],
          backgroundColor: ["#4e73df", "#e74a3b", "#36b9cc", "#f6c23e"]
        }]
      }
    });
  }
});

// ==============================
// Sidebar Submenu Toggle
// ==============================
document.addEventListener("DOMContentLoaded", () => {
  const submenuParents = document.querySelectorAll(".has-submenu");

  submenuParents.forEach(item => {
    item.addEventListener("click", (e) => {
      // Prevent clicks on submenu <p> items from toggling parent
      if (e.target.tagName.toLowerCase() === "p") return;

      // Close other submenus (accordion style)
      submenuParents.forEach(other => {
        if (other !== item) {
          other.classList.remove("active");
          other.innerHTML = other.innerHTML.replace("▾", "▸");
        }
      });

      // Toggle current submenu
      item.classList.toggle("active");

      // Update arrow symbol
      if (item.classList.contains("active")) {
        item.innerHTML = item.innerHTML.replace("▸", "▾");
      } else {
        item.innerHTML = item.innerHTML.replace("▾", "▸");
      }
    });
  });
});

// ==============================
// Admin Manage Inventory Actions
// ==============================
document.addEventListener("DOMContentLoaded", () => {
  const addBtn = document.querySelector(".add-btn");
  const exportBtn = document.querySelector(".export-btn");

  if (addBtn) {
    addBtn.addEventListener("click", () => {
      alert("Add Item button clicked - form modal would open here.");
    });
  }

  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      alert("Exporting inventory data to CSV...");
    });
  }
});
// ==============================
// Logout Confirmation
// ==============================
document.addEventListener("DOMContentLoaded", () => { 
  const logoutBtn = document.querySelector(".logout");
  if (!logoutBtn) return; // safety check

  logoutBtn.addEventListener("click", (e) => {
    e.preventDefault();

    // Create modal overlay
    const confirmBox = document.createElement("div");
    confirmBox.style.cssText = `
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0,0,0,0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    `;

    confirmBox.innerHTML = `
      <div style="background: #fff; padding: 20px; border-radius: 10px; text-align: center; max-width: 300px;">
        <p style="font-size: 16px; margin-bottom: 20px;">Are you sure you want to log out?</p>
        <button id="yesBtn" style="margin-right: 10px; padding: 8px 16px; background: #e74a3b; color: white; border: none; border-radius: 5px; cursor: pointer;">Yes</button>
        <button id="noBtn" style="padding: 8px 16px; background: #36b9cc; color: white; border: none; border-radius: 5px; cursor: pointer;">No</button>
      </div>
    `;

    document.body.appendChild(confirmBox);

    // Handle Yes
    document.getElementById("yesBtn").addEventListener("click", async () => {
      try {
        await fetch("logout.php", { method: "POST" });
      } catch (err) {
        console.error("Logout failed:", err);
      } finally {
        // Always redirect to login page
        window.location.href = "index.php";
      }
    });

    // Handle No
    document.getElementById("noBtn").addEventListener("click", () => {
      document.body.removeChild(confirmBox);
    });
  });
});


//download file via CSV
// Load local jsPDF scripts
function downloadCSV(csv, filename) {
  const csvFile = new Blob([csv], { type: "text/csv" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(csvFile);
  link.download = filename;
  link.style.display = "none";
  document.body.appendChild(link);
  link.click();
}

function exportTableToCSV(filename) {
  const rows = document.querySelectorAll("#requestTable tr");
  const csv = [];

  rows.forEach(row => {
    const cols = row.querySelectorAll("td, th");
    const rowData = [];
    cols.forEach(col => rowData.push(col.innerText.replace(/,/g, " ")));
    csv.push(rowData.join(","));
  });

  downloadCSV(csv.join("\n"), filename);
}

function exportTableToPDF() {
  const doc = new jsPDF('p', 'pt');
  const table = document.getElementById("requestTable");

  const headers = Array.from(table.querySelectorAll("thead th")).map(th => th.innerText);
  const body = Array.from(table.querySelectorAll("tbody tr")).map(tr =>
    Array.from(tr.querySelectorAll("td")).map(td => td.innerText)
  );

  doc.text("Request Table Data", 40, 40);
  doc.autoTable({
    startY: 60,
    head: [headers],
    body: body,
    styles: { fontSize: 12 },
    theme: 'grid'
  });

  doc.save("table_data.pdf");
}

// Download button logic
document.getElementById("downloadBtn").addEventListener("click", function() {
  document.getElementById("downloadOptions").classList.toggle("hidden");
});

document.addEventListener("click", function(e) {
  const btn = document.getElementById("downloadBtn");
  const menu = document.getElementById("downloadOptions");
  if (!btn.contains(e.target) && !menu.contains(e.target)) {
    menu.classList.add("hidden");
  }
});

document.addEventListener("DOMContentLoaded", () => {
  const badge = document.querySelector(".notif-badge");
  if (!badge) return;
  setInterval(async () => {
    const res = await fetch("unread_count.php");
    const { count } = await res.json();
    badge.textContent = count > 0 ? count : "";
    badge.style.display = count > 0 ? "inline-block" : "none";
  }, 30000); // refresh every 30 seconds
});



