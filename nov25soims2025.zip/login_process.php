<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db_connect.php';   // includes log_activity() function

$email    = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');

if (empty($email) || empty($password)) {
    header("Location: index.php?error=All fields are required");
    exit();
}

// Query to check credentials (role is taken from DB)
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Verify password (supports hashed and plain)
    if ($user['password'] === $password || password_verify($password, $user['password'])) {

        // Set session values
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['role']      = $user['role'];      // admin | sub_admin | procurement
        $_SESSION['username']  = $user['username'] ?? $user['email'];
        $_SESSION['fullname']  = trim(
            ($user['first_name']  ?? '') . ' ' .
            (!empty($user['middle_name']) ? $user['middle_name'].' ' : '') .
            ($user['last_name']   ?? '')
        );

        // Log login activity
        log_activity(
            $_SESSION['user_id'],
            "User logged in",
            "Authentication",
            "Success",
            $conn
        );

        // Redirect based on role
        if ($user['role'] === 'admin') {
            header("Location: admindashboard.php");
        } elseif ($user['role'] === 'procurement') {
            header("Location: procurementdashboard.php");
        } else {
            header("Location: userdashboard.php");
        }
        exit();
    } else {
        // Log failed login attempt
        log_activity(
            $user['id'],
            "Failed login attempt (wrong password)",
            "Authentication",
            "Failed",
            $conn
        );
        header("Location: index.php?error=Invalid password");
        exit();
    }
} else {
    // Log failed login (invalid credentials)
    log_activity(
        0,  // unknown user
        "Failed login attempt (unknown credentials)",
        "Authentication",
        "Failed",
        $conn
    );

    header("Location: index.php?error=Invalid credentials");
    exit();
}
