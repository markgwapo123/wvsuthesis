<?php
// ===================================================
// SESSION START (Safe)
// ===================================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ===================================================
// DATABASE CONNECTION
// ===================================================
$host = "localhost";   // XAMPP default
$user = "root";        // XAMPP default
$pass = "";            // No password by default
$db   = "soims";       // Your database name

$conn = new mysqli($host, $user, $pass, $db);

// Connection error handling
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    exit("Database connection failed.");
}

// ===================================================
// UNIVERSAL ACTIVITY LOGGING FUNCTION
// ===================================================
if (!function_exists('log_activity')) {
    function log_activity($user_id, $action, $module, $status = 'Success', $dbConn = null) {

        // Choose which DB connection to use
        if ($dbConn === null) {
            // fallback to global $conn if nothing passed
            if (!isset($GLOBALS['conn'])) {
                return; // no connection available, just skip logging
            }
            $dbConn = $GLOBALS['conn'];
        }

        // Prevent SQL injection (escape values)
        $action  = $dbConn->real_escape_string($action);
        $module  = $dbConn->real_escape_string($module);
        $status  = $dbConn->real_escape_string($status);

        $ip      = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $device  = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

        $ip      = $dbConn->real_escape_string($ip);
        $device  = $dbConn->real_escape_string($device);

        $user_id = intval($user_id);  // force integer for security

        // Insert into logs
        $sql = "
            INSERT INTO activity_logs 
                (user_id, action, module, status, ip_address, device, created_at)
            VALUES 
                ($user_id, '$action', '$module', '$status', '$ip', '$device', NOW())
        ";

        $dbConn->query($sql);
    }
}

?>
