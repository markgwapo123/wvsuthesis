<?php
// auth.php — SECURE ROLE/PERMISSION HANDLER

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db_connect.php';

/**
 * Return the currently logged-in user
 */
function current_user()
{
    if (!isset($_SESSION['user_id'])) {
        return null; // user not logged in
    }

    return [
        'id'    => $_SESSION['user_id'],
        'role'  => $_SESSION['role'] ?? 'guest',           // admin | subadmin | procurement
        'name'  => $_SESSION['fullname'] ?? ($_SESSION['username'] ?? 'Unknown')
    ];
}

/**
 * Check if the current user has a specific permission.
 */
function has_permission($perm): bool
{
    $user = current_user();
    if (!$user) return false;

    $role = $user['role'];

    $permissions = [

        // ADMIN – full access
        'admin' => [
            'users.manage',
            'roles.manage',
            'permissions.manage',
            'inventory.full',
            'inventory.view',
            'inventory.add',
            'inventory.edit',
            'inventory.delete',
            'suppliers.manage',
            'reports.view',
            'reports.export',
            'procurement.view',
            'procurement.send',
            'procurement.update',
            'procurement.history',
            'system.settings'
        ],

        // SUBADMIN – no delete, no user management, no procurement
        'subadmin' => [
            'inventory.view',
            'inventory.add',
            'inventory.update',
            'reports.view',
            'suppliers.view',
            'archive_all.view'
        ],

        // PROCUREMENT – only procurement module
        'procurement' => [
            'procurement.view',
            'procurement.update',
            'procurement.history'
        ],

        'guest' => []
    ];

    return in_array($perm, $permissions[$role] ?? [], true);
}

/**
 * Block users without permission
 */
function require_permission($perm): void
{
    if (!has_permission($perm)) {
        http_response_code(403);
        exit("⛔ Forbidden: You do not have permission: " . htmlspecialchars($perm));
    }
}

/**
 * Require user to have one of the listed roles
 */
function allow_roles(array $roles): void
{
    $user = current_user();
    if (!$user || !in_array($user['role'], $roles, true)) {
        header("Location: index.php?error=Unauthorized");
        exit();
    }
}

/**
 * Simple helper
 */
function is_role(string $role): bool
{
    $u = current_user();
    return $u && $u['role'] === $role;
}
