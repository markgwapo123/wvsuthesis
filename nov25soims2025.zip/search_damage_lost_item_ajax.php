<?php 
require_once "db_connect.php";

/* Pagination */
$page = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$where = [];

/* =======================
   LIVE SEARCH
======================= */
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(item_name LIKE '%$s%' 
                OR category LIKE '%$s%' 
                OR condition_label LIKE '%$s%' 
                OR status_label LIKE '%$s%')";
}

/* =======================
   FILTERS
======================= */
$filters = [
    "category"        => "category",
    "condition_label" => "condition_label",
    "status_label"    => "status_label"
];

foreach ($filters as $key => $col) {
    if (!empty($_POST[$key])) {
        $v = $conn->real_escape_string($_POST[$key]);
        $where[] = "$col LIKE '%$v%'";
    }
}

$whereSQL = empty($where) ? "" : "WHERE " . implode(" AND ", $where);


/* =======================
   UNION QUERY
   - damage_lost_item  (Damage/Lost)
   - inventory         (Expired)
======================= */

/* Count Total */
$countRes = $conn->query("
    SELECT COUNT(*) AS total FROM (
        SELECT d.damage_id
        FROM damage_lost_item d
        UNION ALL
        SELECT i.inventory_id
        FROM inventory i
        WHERE i.status_label = 'Expired' OR i.condition_label = 'Expired'
    ) AS all_rec
");
$totalRows = $countRes->fetch_assoc()['total'];
$totalPages = max(1, ceil($totalRows / $limit));


/* Main Query */
$sql = "
SELECT * FROM (
    /* DAMAGED */
    SELECT 
        d.damage_id AS id,
        i.name AS item_name,
        i.category,
        d.quantity AS qty,
        d.condition_label,
        'Damaged' AS status_label,
        d.date_recorded AS updated_at
    FROM damage_lost_item d
    LEFT JOIN inventory i ON i.inventory_id = d.inventory_id

    UNION ALL

    /* EXPIRED ITEMS FROM INVENTORY */
    SELECT 
        i.inventory_id AS id,
        i.name AS item_name,
        i.category,
        i.quantity AS qty,
        i.condition_label,
        i.status_label,
        i.updated_at
    FROM inventory i
    WHERE i.status_label = 'Expired' OR i.condition_label = 'Expired'
) AS all_items
$whereSQL
ORDER BY updated_at DESC
LIMIT $limit OFFSET $offset
";

$res = $conn->query($sql);

/* =======================
   OUTPUT TABLE
======================= */

echo "
<table class='table'>
<thead>
<tr>
  <th>ID</th>
  <th>Name</th>
  <th>Category</th>
  <th>Qty</th>
  <th>Condition</th>
  <th>Status</th>
  <th>Last Update</th>
</tr>
</thead>
<tbody>
";

if ($res && $res->num_rows > 0) {
    while ($r = $res->fetch_assoc()) {

        /* COLOR ROW CLASSES */
        $cls = "";
        $cond = strtolower($r['condition_label']);
        $status = strtolower($r['status_label']);

        if ($cond == "damage" || $cond == "damaged") $cls = "bad";
        if ($cond == "lost" || $status == "lost") $cls = "lost";
        if ($cond == "expired" || $status == "expired") $cls = "expired";

        echo "
        <tr class='$cls'>
            <td>{$r['id']}</td>
            <td>".htmlspecialchars($r['item_name'])."</td>
            <td>".htmlspecialchars($r['category'])."</td>
            <td>{$r['qty']}</td>
            <td>{$r['condition_label']}</td>
            <td>{$r['status_label']}</td>
            <td>{$r['updated_at']}</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='7'>No records found.</td></tr>";
}

echo "</tbody></table>";

/* Pagination Output */
echo "<div class='pagination'>";
if ($page > 1) echo "<span class='page-link' data-page='".($page-1)."'>Previous</span>";

for ($i = 1; $i <= $totalPages; $i++) {
    $active = ($i == $page) ? "active" : "";
    echo "<span class='page-link $active' data-page='$i'>$i</span>";
}

if ($page < $totalPages) echo "<span class='page-link' data-page='".($page+1)."'>Next</span>";
echo "</div>";
?>
