<?php 
require_once "db_connect.php";

/*-------------------------------------------------------
  PAGINATION
-------------------------------------------------------*/
$page   = isset($_POST['page']) ? max(1, intval($_POST['page'])) : 1;
$limit  = 20;
$offset = ($page - 1) * $limit;

/*-------------------------------------------------------
  BUILD WHERE CONDITIONS (FILTERS + LIVE SEARCH)
-------------------------------------------------------*/
$where = [];

// LIVE SEARCH
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(u.item_name LIKE '%$s%' 
                 OR u.department LIKE '%$s%' 
                 OR u.processed_by LIKE '%$s%' 
                 OR u.requestor_name LIKE '%$s%' 
                 OR i.category LIKE '%$s%')";
}

// DATE FILTERS
if (!empty($_POST['from'])) {
    $from = $conn->real_escape_string($_POST['from']);
    $where[] = "DATE(u.issued_at) >= '$from'";
}
if (!empty($_POST['to'])) {
    $to = $conn->real_escape_string($_POST['to']);
    $where[] = "DATE(u.issued_at) <= '$to'";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

/*-------------------------------------------------------
  COUNT ROWS
-------------------------------------------------------*/
$countRes = $conn->query("
  SELECT COUNT(*) AS total 
  FROM issuances u
  LEFT JOIN inventory i ON i.name = u.item_name
  $whereSQL
");
$totalRows  = $countRes ? (int)$countRes->fetch_assoc()['total'] : 0;
$totalPages = max(1, ceil($totalRows / $limit));

/*-------------------------------------------------------
  MAIN QUERY — category added
-------------------------------------------------------*/
$sql = "
SELECT 
  u.issuance_id,
  u.order_id,
  u.item_name,
  u.issued_qty,
  u.processed_by,
  u.department,
  u.requestor_name,
  u.remarks,
  u.issued_at,
  i.category
FROM issuances u
LEFT JOIN inventory i 
    ON i.name = u.item_name   -- FIXED: removed u.inventory_id
$whereSQL
ORDER BY u.issued_at DESC
LIMIT $limit OFFSET $offset
";

$res = $conn->query($sql);

/*-------------------------------------------------------
  OUTPUT TABLE
-------------------------------------------------------*/
echo "
<table class='table'>
<thead>
<tr>
  <th>ID</th>
  <th>Order ID</th>
  <th>Item Name</th>
  <th>Category</th>
  <th>Issued Qty</th>
  <th>Processed By</th>
  <th>Department</th>
  <th>Requestor</th>
  <th>Remarks</th>
  <th>Date Issued</th>
</tr>
</thead>
<tbody>
";

if ($res && $res->num_rows > 0) {

    while ($r = $res->fetch_assoc()) {

        echo "
        <tr>
          <td>{$r['issuance_id']}</td>
          <td>{$r['order_id']}</td>
          <td>" . htmlspecialchars($r['item_name']) . "</td>
          <td>" . htmlspecialchars($r['category'] ?? 'N/A') . "</td>
          <td>{$r['issued_qty']}</td>
          <td>" . htmlspecialchars($r['processed_by']) . "</td>
          <td>" . htmlspecialchars($r['department']) . "</td>
          <td>" . htmlspecialchars($r['requestor_name']) . "</td>
          <td>" . htmlspecialchars($r['remarks']) . "</td>
          <td>" . htmlspecialchars($r['issued_at']) . "</td>
        </tr>";
    }

} else {
    echo "<tr><td colspan='10'>No records found.</td></tr>";
}

echo "</tbody></table>";

/*-------------------------------------------------------
  PAGINATION
-------------------------------------------------------*/
echo "<div class='pagination'>";

if ($page > 1) {
  echo "<span class='page-link' data-page='".($page-1)."'>Previous</span>";
}

for ($i = 1; $i <= $totalPages; $i++) {
  $active = ($i == $page) ? "active" : "";
  echo "<span class='page-link $active' data-page='$i'>$i</span>";
}

if ($page < $totalPages) {
  echo "<span class='page-link' data-page='".($page+1)."'>Next</span>";
}

echo "</div>";
?>
