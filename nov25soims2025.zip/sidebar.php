<?php
require_once __DIR__ . '/db_connect.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/auth.php';

$role   = $_SESSION['role'] ?? 'guest';
$userId = $_SESSION['user_id'] ?? null; // make sure you set this when logging in

// notifications
$unread_count = 0;
$res = $conn->query("SELECT COUNT(*) AS c FROM notifications WHERE is_read = 0");
if ($res && $r = $res->fetch_assoc()) {
    $unread_count = (int)$r['c'];
}

// profile image (from users.profile_img)
$profileImage = 'images/default-avatar.png'; // fallback image

if ($userId) {
    if ($stmt = $conn->prepare("SELECT profile_img FROM users WHERE id = ? LIMIT 1")) {
        $stmt->bind_param("i", $userId);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result && $userRow = $result->fetch_assoc()) {
                if (!empty($userRow['profile_img'])) {
                    $profileImage = $userRow['profile_img']; // assume this is a path like 'uploads/xxx.jpg'
                }
            }
        }
        $stmt->close();
    }
}


$profileImage = htmlspecialchars($profileImage, ENT_QUOTES, 'UTF-8');
$displayRole  = htmlspecialchars(ucfirst($role), ENT_QUOTES, 'UTF-8');
?>
<style>
  /* You can move this to your main CSS file */
  .sidebar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 1rem;
  }

  .sidebar-header .logo {
    margin: 0;
    font-size: 30px;
  }

  .profile-avatar-btn {
    border: none;
    background: transparent;
    padding: 0;
    cursor: pointer;
  }

  .profile-avatar {
    width: 65px;
    height: 65px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid rgba(255, 255, 255, 0.3);
  }

  .profile-avatar:hover {
    filter: brightness(1.05);
  }
</style>

<aside class="sidebar">
  <!-- Role (left) + profile photo (right, clickable to manage_account.php) -->
  <div class="sidebar-header">
    <h2 class="logo"><?= $displayRole ?></h2>
    <button
      class="profile-avatar-btn"
      type="button"
      onclick="window.location.href='manage_account.php'">
      <img src="<?= $profileImage ?>" alt="Profile" class="profile-avatar">
    </button>
  </div>

  <ul class="menu">
    <?php if ($role === 'admin'): ?>
      <li onclick="window.location.href='Admindashboard.php'">📊 Overview</li>
    <?php elseif ($role === 'subadmin'): ?>
      <li onclick="window.location.href='userdashboard.php'">📊 Overview</li>
    <?php elseif ($role === 'procurement'): ?>
      <li onclick="window.location.href='procurementdashboard.php'">📊 Procurement Overview</li>
    <?php endif; ?>

    <!-- Inventory Management: ADMIN + SUBADMIN -->
    <?php if ($role === 'admin' || $role === 'subadmin'): ?>
    <li class="has-submenu">
      📦 Inventory Management <span class="arrow">▸</span>
      <div class="submenu">
        <p onclick="window.location.href='manage_inventory.php'">Manage Item</p>
        <p onclick="window.location.href='order_management.php'">Order Management</p>
        <p onclick="window.location.href='borrow_item.php'">Borrow Item</p>
        <p onclick="window.location.href='return_item.php'">Return Item</p>
        <p onclick="window.location.href='manage_suppliers.php'">Suppliers List</p>
        <p onclick="window.location.href='generate_barcode.php'">Barcode Management</p>
      </div>
    </li>
    <?php endif; ?>

    <!-- User Management: ADMIN ONLY -->
    <?php if ($role === 'admin'): ?>
    <li class="has-submenu">
      👥 User Management <span class="arrow">▸</span>
      <div class="submenu">
        <p onclick="window.location.href='users.php'">Users</p>
        <p onclick="window.location.href='assign_roles_permissions.php'">Assign Roles & Permissions</p>
        <p onclick="window.location.href='view_user_activity.php'">View User Activity Log</p>
      </div>
    </li>
    <?php endif; ?>

    <!-- Reports: ADMIN + SUBADMIN -->
    <?php if ($role === 'admin' || $role === 'subadmin'): ?>
    <li class="has-submenu">
      📑 Reports <span class="arrow">▸</span>
      <div class="submenu">
        <p onclick="window.location.href='inventory_summary_report.php'">Inventory Summary Report</p>
        <p onclick="window.location.href='issuance_report.php'">Issuance Report</p>
        <p onclick="window.location.href='stock_levels.php'">Stock In Report</p>
        <p onclick="window.location.href='borrow_item_report.php'">Item Borrowed Report</p>
        <p onclick="window.location.href='item_return_report.php'">Item Return Report</p>
        <p onclick="window.location.href='damage_lost_item.php'">Damage/Lost Item Report</p>
        <p onclick="window.location.href='expiring_item.php'">Expiring Item Report</p>
      </div>
    </li>
    <?php endif; ?>

    <!-- Procurement-only menu -->
    <?php if ($role === 'procurement'): ?>
      <li onclick="window.location.href='procurementdashboard.php'">📝 Requests to Process</li>
      <li onclick="window.location.href='procurement_history.php'">📋 Procurement History</li>
    <?php endif; ?>

    <!-- Common -->
    <li onclick="window.location.href='notification.php'" style="position:relative;">
      🔔 Notification
      <?php if ($unread_count > 0): ?>
        <span class="notif-badge"><?= $unread_count ?></span>
      <?php endif; ?>
    </li>

    <?php if ($role === 'admin' || $role === 'subadmin'): ?>
      <li onclick="window.location.href='archive_all.php'">🗄️ Archive</li>
      <li onclick="window.location.href='settings.php'">⚙️ Settings</li>
      <li onclick="window.location.href='support.php'">🆘 Support</li>
    <?php endif; ?>
  </ul>

  <button class="logout">⬅ Logout</button>
</aside>
