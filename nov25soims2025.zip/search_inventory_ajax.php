<?php
require_once 'db_connect.php';
require_once 'auth.php';   // IMPORTANT: Needed for role permissions

$page  = isset($_POST['page']) ? max(1, (int)$_POST['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = [];

/*----------------------------------------------
  LIVE SEARCH
----------------------------------------------*/
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(name LIKE '%$s%' 
                 OR category LIKE '%$s%' 
                 OR COALESCE(department,'') LIKE '%$s%')";
}

/*----------------------------------------------
  FILTERS
----------------------------------------------*/
if (!empty($_POST['department'])) {
    $d = $conn->real_escape_string($_POST['department']);
    $where[] = "COALESCE(department,'No Department') LIKE '%$d%'";
}

if (!empty($_POST['category'])) {
    $c = $conn->real_escape_string($_POST['category']);
    $where[] = "category LIKE '%$c%'";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

/*----------------------------------------------
  COUNT GROUPS
----------------------------------------------*/
$countSql = "
    SELECT COUNT(*) AS total_groups
    FROM (
        SELECT 1
        FROM inventory
        $whereSQL
        GROUP BY name, COALESCE(department,'No Department')
    ) AS g
";
$countRes = $conn->query($countSql);
$totalRows = $countRes ? (int)$countRes->fetch_assoc()['total_groups'] : 0;
$totalPages = max(1, ceil($totalRows / $limit));

/*----------------------------------------------
  FETCH GROUPED INVENTORY
----------------------------------------------*/
$query = "
    SELECT 
        MIN(inventory_id) AS inventory_id, -- needed for procurement ID
        name,
        COALESCE(department,'No Department') AS department,
        SUM(quantity) AS total_qty,
        -- min_stock (assume same per group; use MIN as representative)
        MIN(min_stock) AS min_stock,
        GROUP_CONCAT(DISTINCT unit) AS units,
        GROUP_CONCAT(DISTINCT category) AS categories,
        GROUP_CONCAT(DISTINCT condition_label) AS conds,
        GROUP_CONCAT(DISTINCT status_label) AS statuses,
        GROUP_CONCAT(DISTINCT supplier_id) AS supplier_ids,
        MIN(expiration_date) AS min_expiration,
        MAX(expiration_date) AS max_expiration,
        MIN(CASE WHEN image_path IS NOT NULL AND image_path <> '' 
                 THEN image_path END) AS image_path
    FROM inventory
    $whereSQL
    GROUP BY name, COALESCE(department,'No Department')
    ORDER BY name ASC
    LIMIT $limit OFFSET $offset
";

$res = $conn->query($query);

/*----------------------------------------------
  HELPER — NORMALIZE LIST LABEL
----------------------------------------------*/
function normalizeListLabel(?string $csv)
{
  if (!$csv) return '-';

  $parts = array_unique(array_filter(
    array_map('trim', explode(',', $csv)),
    fn($v) => $v !== '' && $v !== 'NULL'
  ));

  if (count($parts) === 0) return '-';
  if (count($parts) === 1) return $parts[0];

  return "Mixed";
}

/*----------------------------------------------
  TABLE OUTPUT
----------------------------------------------*/

echo "
<style>
.badge {
  padding: 4px 8px;
  border-radius: 4px;
  color: white;
  font-size: 12px;
  font-weight: bold;
}
.badge-available { background: #28a745; }
.badge-low { background: #ffc107; color:black; }
.badge-out { background: #dc3545; }
.badge-disposed { background: #6c757d; }
.edit-btn {
  padding: 5px 8px; background:#007bff; border:none; color:white;
  cursor:pointer; border-radius:3px; font-size:12px;
}
.delete-btn {
  padding: 5px 8px; background:#dc3545; border:none; color:white;
  cursor:pointer; border-radius:3px; font-size:12px;
}
.proc-btn {
  padding: 5px 8px; background:#ff8800; border:none; color:white;
  cursor:pointer; border-radius:3px; font-size:12px;
}
</style>
";

echo "
<table class='table'>
  <thead>
    <tr>
      <th>Item Name</th>
      <th>Department</th>
      <th>Total Qty</th>
      <th>Unit</th>
      <th>Category</th>
      <th>Condition</th>
      <th>Status</th>
      <th>Min Stock</th>
      <th>Suppliers</th>
      <th>Expiration</th>
      <th>Image</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
";

if (!$res || $res->num_rows === 0) {
  echo "<tr><td colspan='12'>No items found.</td></tr>";
} else {
  while ($row = $res->fetch_assoc()) {

    $name = $row['name'];
    $dept = $row['department'];
    $inventory_id = (int)$row['inventory_id'];

    $nameParam = urlencode($name);
    $deptParam = urlencode($dept);

    /* CLEAN VALUES */
    $totalQty  = (int)$row['total_qty'];
    $minStock  = isset($row['min_stock']) ? (int)$row['min_stock'] : null;

    $unit      = normalizeListLabel($row['units']);
    $category  = normalizeListLabel($row['categories']);
    $condition = normalizeListLabel($row['conds']);
    $status    = normalizeListLabel($row['statuses']);

    $supplierIds = $row['supplier_ids']
      ? implode(', ', array_unique(array_filter(array_map('trim', explode(',', $row['supplier_ids'])))))
      : '-';

    $minExp = $row['min_expiration'];
    $maxExp = $row['max_expiration'];
    $expDisplay = $minExp
      ? ($minExp !== $maxExp ? "$minExp to $maxExp" : $minExp)
      : "-";

    $imgHtml = $row['image_path']
      ? "<img src='" . htmlspecialchars($row['image_path']) . "' style='width:40px;height:40px;border-radius:4px;'>"
      : "<span style='color:#888;'>No image</span>";

    // Update status based on the conditions
    if ($totalQty == 0) {
        $status = 'Out of Stock';
    } elseif (in_array(strtolower($category), ['expired', 'damage', 'lost'])) {
        $status = 'Disposed';
    } elseif ($totalQty <= $minStock) {
        $status = 'Low Stock';
    } elseif ($status == 'Borrowed') {
        $status = 'Borrowed';
    } elseif ($totalQty > $minStock) {
        $status = 'Available';
    }

    // Update the status in the database
    $conn->query("UPDATE inventory SET status_label = '$status' WHERE inventory_id = $inventory_id");

    echo "<tr>
          <td>" . htmlspecialchars($name) . "</td>
          <td>" . htmlspecialchars($dept) . "</td>
          <td>{$totalQty}</td>
          <td>" . htmlspecialchars($unit) . "</td>
          <td>" . htmlspecialchars($category) . "</td>
          <td>" . htmlspecialchars($condition) . "</td>
          <td>" . htmlspecialchars($status) . "</td>
          <td>" . htmlspecialchars($minStock ?? '-') . "</td>
          <td>" . htmlspecialchars($supplierIds) . "</td>
          <td>{$expDisplay}</td>
          <td>{$imgHtml}</td>
          <td>
        ";

    /*----------------------------------------------
          ROLE-BASED ACTION BUTTONS
        ----------------------------------------------*/

    if (is_role('admin')) {

      // EDIT
      echo "
<button class='edit-btn'
    onclick=\"window.location.href='edit_record.php?type=inventory&group=1&name={$nameParam}&department={$deptParam}'\">
  Edit
</button>
";

      // DELETE
      echo "
            <button class='delete-btn'
              onclick=\"deleteGroup('" . htmlspecialchars($name, ENT_QUOTES) . "','" . htmlspecialchars($dept, ENT_QUOTES) . "')\">
              Delete
            </button>
            ";

      // SEND TO PROCUREMENT (Low stock or Out of stock)
      if ($totalQty <= 5) {
        $needed = max(1, 5 - $totalQty);
        echo "
                <button class='proc-btn'
                    onclick=\"window.location.href='send_to_procurement.php?inventory_id={$inventory_id}&qty={$needed}'\">
                  Send to Procurement
                </button>
                ";
      }
    } elseif (is_role('subadmin')) {
      echo "<span class='badge badge-low'>View Only</span>";
    } else {
      echo "<span class='badge badge-low'>Restricted</span>";
    }

    echo "</td></tr>";
  }
}

echo "</tbody></table>";

/*----------------------------------------------
  PAGINATION
----------------------------------------------*/
echo "<div class='pagination'>";

if ($page > 1) {
  echo "<span class='page-link' data-page='" . ($page - 1) . "'>Previous</span>";
}

for ($i = 1; $i <= $totalPages; $i++) {
  $active = ($i == $page) ? "active" : "";
  echo "<span class='page-link {$active}' data-page='{$i}'>{$i}</span>";
}

if ($page < $totalPages) {
  echo "<span class='page-link' data-page='" . ($page + 1) . "'>Next</span>";
}

echo "</div>";
