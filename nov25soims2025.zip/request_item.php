<?php
require_once 'db_connect.php'; // Database connection

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] == 'create') {
  // Collect form data
  $requestor = $_POST['requestor'];
  $department = $_POST['department'];
  $item_name = $_POST['item_name'];
  $qty = $_POST['qty'];
  $order_date = $_POST['order_date'];
  $expected_date = $_POST['expected_date'];
  $processed_by = $_POST['processed_by'];
  $unit = $_POST['unit'];

  // Insert the order into the database
  $sql = "INSERT INTO orders (requestor_name, department, item_name, qty, order_date, expected_date, processed_by, unit)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssssssss", $requestor, $department, $item_name, $qty, $order_date, $expected_date, $processed_by, $unit);

  if ($stmt->execute()) {
    // Success message
    $success_message = "Order has been placed successfully!";
    // Redirect after successful form submission to prevent resubmission
    header("Location: request_item.php?success=true");
    exit();  // Make sure the rest of the code doesn't run after redirect
  } else {
    // Error message
    $error_message = "There was an error placing the order. Please try again.";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Create Order</title>
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(135deg, #143ab7ff, #143ab7ff);
      margin: 0;
      padding: 0;
      color: #333;
    }

    .main-content {
      max-width: 800px;
      margin: 50px auto;
      background: #fff;
      border-radius: 20px;
      padding: 40px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      animation: fadeIn 0.6s ease;
    }

    h1 {
      text-align: center;
      color: #3b3b98;
      margin-bottom: 25px;
    }

    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
    }

    input,
    select {
      height: 80%;
      padding: 10px 12px;
      border-radius: 10px;
      border: 1px solid #ccd6f6;
      font-size: 14px;
      background-color: #fafaff;
      transition: all 0.3s ease;
    }

    input:focus,
    select:focus {
      outline: none;
      border-color: #2c69daff;
      box-shadow: 0 0 4px rgba(47, 57, 252, 0.3);
    }

    .form-group {
      position: relative;
      margin-top: 20px;
      bottom: 20px;
    }

    .form-group input {
      width: 94%;
      padding: 10px 12px;
      font-size: 14px;
    }

    .form-group label {
      position: absolute;
      top: 10px;
      left: 120px;
      color: #777;
      transition: 0.2s;
      pointer-events: none;
    }

    .form-group input:focus+label,
    .form-group input:valid+label {
      top: -10px;
      left: 10px;
      font-size: 12px;
      color: #000;
      background: #fff;
      padding: 0 4px;
    }

    .submit-btn {
      grid-column: 1 / 3;
      padding: 12px;
      background-color: #395ffaff;
      color: #fff;
      border: none;
      border-radius: 12px;
      cursor: pointer;
      font-size: 15px;
      transition: background-color 0.3s, transform 0.2s;
    }

    .submit-btn:hover {
      background-color: #180fcaff;
      transform: translateY(-2px);
    }

    .back-btn {
      display: block;
      margin: 25px auto 0;
      background-color: #ff7b9c;
      color: #fff;
      border: none;
      padding: 10px 25px;
      border-radius: 10px;
      font-size: 14px;
      cursor: pointer;
      transition: background 0.3s, transform 0.2s;
    }

    .back-btn:hover {
      background-color: #ff4f7a;
      transform: translateY(-2px);
    }

    /* Success/Error alert */
    .alert {
      background-color: #4CAF50;
      color: white;
      padding: 15px;
      margin-top: 20px;
      text-align: center;
      border-radius: 5px;
      display: none;
    }

    .alert.error {
      background-color: #f44336;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>

<body>
  <div class="main-content">
    <h1>Request Item</h1>

    <!-- Show success or error message -->
    <?php if (isset($success_message)): ?>
      <div class="alert"><?= $success_message ?></div>
      <script>
        setTimeout(() => {
          document.querySelector('.alert').style.display = 'none';
        }, 5000); // Hide after 5 seconds
      </script>
    <?php elseif (isset($error_message)): ?>
      <div class="alert error"><?= $error_message ?></div>
      <script>
        setTimeout(() => {
          document.querySelector('.alert').style.display = 'none';
        }, 5000); // Hide after 5 seconds
      </script>
    <?php endif; ?>

    <form id="createOrder" enctype="multipart/form-data" method="post" action="request_item.php">
      <input type="hidden" name="action" value="create">

      <div class="grid">
        <div class="form-group">
          <input name="requestor" id="requestor" required>
          <label for="requestor">Requestor</label>
        </div>
        <div class="form-group">
          <input name="department" id="department" required>
          <label for="department">Department</label>
        </div>
        <div class="form-group">
          <input name="item_name" id="item_name" required>
          <label for="item_name">Item Name</label>
        </div>
        <div class="form-group">
          <input name="qty" id="qty" type="number" min="1" required>
          <label for="qty">Quantity</label>
        </div>
        <div class="form-group">
          <input type="date" name="order_date" id="order_date" required>
          <label for="order_date">Order Date</label>
        </div>

        <div class="form-group">
          <input type="date" name="expected_date" id="expected_date" required>
          <label for="expected_date">Expected Date Receive</label>
        </div>
        <div class="form-group">
          <input name="processed_by" id="processed_by" type="number" min="1" required>
          <label for="processed_by">Processed By (User ID)</label>
        </div>
        <select name="unit">
          <option>Item Unit</option>
          <option>Pieces</option>
          <option>Boxes</option>
          <option>Ream</option>
          <option>Pack</option>
          <option>Case</option>
        </select>
        <button type="submit" class="submit-btn">Submit Request</button>
      </div>
    </form>

    <button class="back-btn" onclick="window.location.href='order_management.php'">← Back to Order Management</button>
  </div>
</body>
</html>
