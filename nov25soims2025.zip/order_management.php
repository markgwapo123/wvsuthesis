<?php
require_once 'db_connect.php';

// Load theme settings (same pattern as other pages)
$settingsQuery = $conn->query("SELECT * FROM user_settings WHERE user_id = 1 LIMIT 1");
$settings = ($settingsQuery && $settingsQuery->num_rows > 0)
  ? $settingsQuery->fetch_assoc()
  : ['theme' => 'light'];
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Order Management</title>
  <link rel="stylesheet" href="admindasboard.css">
  <style>
    .table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    .table th,
    .table td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: center;
      font-size: 14px;
    }

    .table th {
      background: #007bff;
      color: white;
    }

    button {
      padding: 5px 10px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 13px;
    }

    button.delete {
      background: #dc3545;
      color: white;
    }

    button.issue {
      background: #28a745;
      color: white;
    }

    button.view {
      background: #17a2b8;
      color: #fff;
    }

    button.delete:hover {
      background: #b52a37;
    }

    button.issue:hover {
      background: #218838;
    }

    button.view:hover {
      background: #138496;
    }

    select {
      padding: 5px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    /* top controls similar to manage_inventory */
    .filter-bar {
      margin-bottom: 10px;
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      align-items: right;
    }

    .filter-bar form label {
      font-size: 13px;
      display: flex;
      flex-direction: column;
    }

    .filter-bar input {
      padding: 4px 6px;
      font-size: 13px;
    }

    .add-btn {
      background: #007bff;
      color: #fff;
      padding: 8px 14px;
      border-radius: 5px;
      border: none;
      cursor: pointer;
    }

    .add-btn:hover {
      background: #0056b3;
    }

    .dl-btn {
      background: #007bff;
      color: #fff;
      padding: 8px 14px;
      border-radius: 5px;
      border: none;
      cursor: pointer;
      font-size: 13px;
      align-items: right;
    }

    .dl-btn:hover {
      background: #0056b3;
    }

    .pagination {
      margin-top: 10px;
      text-align: center;
    }

    .pagination .page-link {
      display: inline-block;
      padding: 4px 8px;
      margin: 0 2px;
      border: 1px solid #777;
      cursor: pointer;
      font-size: 13px;
    }

    .pagination .page-link.active {
      background: #007bff;
      color: #fff;
    }

    /* Modal reused by tableModule.js (optional View details) */
    #ordModalOverlay {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }

    #ordModal {
      background: #fff;
      border-radius: 8px;
      padding: 20px;
      max-width: 800px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
      font-size: 14px;
    }

    #ordModalClose {
      float: right;
      border: none;
      background: #dc3545;
      color: #fff;
      padding: 4px 8px;
      border-radius: 4px;
      cursor: pointer;
      font-size: 12px;
    }
  </style>
</head>

<body class="<?= ($settings['theme'] ?? 'light') == 'dark' ? 'dark-mode' : '' ?>">
  <div class="dashboard">
    <?php include 'sidebar.php'; ?>

    <main class="main-content">
      <div class="inventory-container">
        <header class="header">
          <h1>Order Management</h1>
          <div class="search-bar">
            <!-- LIVE SEARCH (AJAX) -->
            <input type="text" id="liveSearch" placeholder="Search by requestor / dept / item / status">
            <button type="button"><span>&#128269;</span></button>
          </div>
        </header>

        <div class="content-box">
          <div class="top-left">
            <button class="add-btn" onclick="window.location.href='request_item.php'">
              ➕ Request Item
            </button>
          </div>
          <!-- Top bar: Request button + filters -->
          <div class="filter-bar">
            <form id="filterForm" style="display:flex; gap:10px; flex-wrap:wrap; margin-right:auto;">
              <label>
                Department
                <input type="text" name="department" placeholder="Dept">
              </label>
              <label>
                Status
                <input type="text" name="status" placeholder="Status">
              </label>
              <label>
                Requestor
                <input type="text" name="requestor" placeholder="Requestor">
              </label>
              <label>
                Item
                <input type="text" name="item" placeholder="Item name">
              </label>
              <label>
                From
                <input type="date" name="from">
              </label>
              <label>
                To
                <input type="date" name="to">
              </label>
              <button type="submit" class="add-btn" style="background:#6c757d;">Apply</button>
            </form>
          </div>

          <!-- TABLE CONTAINER (AJAX) -->
          <div id="ordersTable">
            Loading orders...
          </div>

          <!-- Export buttons bottom-right (similar placement) -->
          <div style="margin-top:15px; display:flex; justify-content:flex-start; gap:10px;">
            <button id="btnCSV" class="dl-btn" style="background:#17a2b8;">Download CSV</button>
            <button id="btnExcel" class="dl-btn" style="background:#28a745;">Download Excel</button>
            <button id="btnPDF" class="dl-btn" style="background:#6f42c1;">Download PDF</button>
          </div>

        </div>
      </div>
    </main>
  </div>

  <!-- Modal (optional) -->
  <div id="ordModalOverlay">
    <div id="ordModal">
      <button id="ordModalClose">Close</button>
      <h2>Order Details</h2>
      <div id="ordModalContent"></div>
    </div>
  </div>

  <script src="chart.umd.min.js"></script>
  <script src="admindashboard.js" defer></script>
  <script src="assets/js/jspdf.umd.min.js"></script>
  <script src="assets/js/jspdf.plugin.autotable.min.js"></script>
  <script src="assets/js/tableModule.js"></script>

  <script>
    // Attach to universal tableModule.js
    initTableModule({
      ajaxUrl: "/SUPPLY_OFFICE_first/orders_ajax.php",
      filterForm: "#filterForm",
      liveSearch: "#liveSearch",
      tableContainer: "#ordersTable",

      modalOverlay: "#ordModalOverlay",
      modalClose: "#ordModalClose",
      modalContent: "#ordModalContent",

      exportCSVBtn: "#btnCSV",
      exportExcelBtn: "#btnExcel",
      exportPDFBtn: "#btnPDF",

      exportFileName: "orders",
      exportTitle: "Order List"
    });

    // ========= Reuse your existing API (orders_api.php) =========
    // After actions, we refresh the table by re-submitting the filter form
    async function updateStatus(order_id, status) {
      const fd = new FormData();
      fd.append('action', 'update_status');
      fd.append('order_id', order_id);
      fd.append('status', status);

      await fetch('orders_api.php', {
        method: 'POST',
        body: fd
      });

      const form = document.getElementById('filterForm');
      if (form) form.dispatchEvent(new Event('submit'));
    }

    async function deleteOrder(order_id) {
      if (!confirm('Are you sure you want to delete this order?')) return;

      const fd = new FormData();
      fd.append('action', 'delete');
      fd.append('order_id', order_id);

      await fetch('orders_api.php', {
        method: 'POST',
        body: fd
      });

      const form = document.getElementById('filterForm');
      if (form) form.dispatchEvent(new Event('submit'));
    }

    function goIssuance(order_id) {
      window.location.href = 'issuance.php?order_id=' + order_id;
    }
  </script>
</body>

</html>