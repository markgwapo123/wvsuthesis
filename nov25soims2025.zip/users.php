<?php
session_start();
require_once __DIR__ . '/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php?error=Unauthorized");
    exit();
}

// Load theme settings
$settingsQuery = $conn->query("SELECT * FROM user_settings WHERE user_id = 1 LIMIT 1");
$settings = ($settingsQuery && $settingsQuery->num_rows > 0)
            ? $settingsQuery->fetch_assoc()
            : ['theme' => 'light'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Management</title>
<link rel="stylesheet" href="admindasboard.css">

<style>
.table {
  width: 100%;
  border-collapse: collapse;
}
.table th, .table td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: center;
  font-size: 14px;
}
.table th {
  background: #007bff;
  color: #fff;
}

.add-btn {
  background: #007bff;
  color:#fff;
  padding:10px 15px;
  border-radius:5px;
  border:none;
  cursor:pointer;
}
.add-btn:hover { background:#0056b3; }

.apply-btn {
  background: #007bff;
  color:#fff;
  padding:10px 15px;
  border-radius:5px;
  border:none;
  cursor:pointer;
}
.apply-btn:hover { background:#0056b3; }


.dl-btn {
  padding: 10px 15px;
  color:#fff;
  border-radius:5px;
  border:none;
  cursor:pointer;
}
</style>
</head>

<body class="<?= ($settings['theme']=='dark') ? 'dark-mode' : '' ?>">
<div class="dashboard">

<?php include 'sidebar.php'; ?>

<main class="main-content">
<div class="inventory-container">

<header class="header">
    <h1>User Management</h1>
    <div class="search-bar">
        <input type="text" id="liveSearch" placeholder="Search users...">
        <button><span>&#128269;</span></button>
    </div>
</header>

<div class="content-box">

    <!-- ADD USER BUTTON -->
    <button class="add-btn" onclick="window.location='signup.php'">➕ Add User</button>

    <!-- FILTERS -->
    <form id="filterForm" style="display:flex; gap:10px; margin:15px 0; flex-wrap:wrap;">
        <label>
            Role:
            <input type="text" name="role" placeholder="admin/user">
        </label>
        <label>
            Created After:
            <input type="date" name="created_from">
        </label>
        <button class="apply-btn" style="background:#6c757d;">Apply</button>
    </form>
    <!-- TABLE LOADS HERE -->
    <div id="usersTable">Loading users...</div>

    <!-- EXPORT BUTTONS -->
    <div style="margin-bottom:15px;">
        <button id="btnCSV" class="dl-btn" style="background:#17a2b8;">CSV</button>
        <button id="btnExcel" class="dl-btn" style="background:#28a745;">Excel</button>
        <button id="btnPDF" class="dl-btn" style="background:#6f42c1;">PDF</button>
    </div>


</div>
</main>
</div>

<!-- MODAL -->
<div id="usrModalOverlay" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.5); justify-content:center; align-items:center;">
  <div id="usrModal" style="background:#fff; border-radius:8px; padding:20px; width:90%; max-width:700px;">
      <button id="usrModalClose" style="float:right; background:#dc3545; color:#fff; border:none; padding:5px 10px;">Close</button>
      <h2>User Details</h2>
      <div id="usrModalContent"></div>
  </div>
</div>

<script src="chart.umd.min.js"></script>
<script src="admindashboard.js" defer></script>

<script src="assets/js/jspdf.umd.min.js"></script>
<script src="assets/js/jspdf.plugin.autotable.min.js"></script>
<script src="assets/js/tableModule.js"></script>

<script>
initTableModule({
    ajaxUrl: "/SUPPLY_OFFICE_first/search_users_ajax.php",
    filterForm: "#filterForm",
    liveSearch: "#liveSearch",
    tableContainer: "#usersTable",

    modalOverlay: "#usrModalOverlay",
    modalClose: "#usrModalClose",
    modalContent: "#usrModalContent",

    exportCSVBtn: "#btnCSV",
    exportExcelBtn: "#btnExcel",
    exportPDFBtn: "#btnPDF",

    exportFileName: "users_list",
    exportTitle: "Users List"
});
</script>

</body>
</html>
