<?php  
require_once 'db_connect.php';

$page  = isset($_POST['page']) ? max(1, (int)$_POST['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$where = [];

// Live search
if (!empty($_POST['live'])) {
    $s = $conn->real_escape_string($_POST['live']);
    $where[] = "(
        requestor_name LIKE '%$s%' OR
        department LIKE '%$s%' OR
        item_name LIKE '%$s%' OR
        status LIKE '%$s%'
    )";
}

// Filters
if (!empty($_POST['department'])) {
    $d = $conn->real_escape_string($_POST['department']);
    $where[] = "department LIKE '%$d%'";
}
if (!empty($_POST['status'])) {
    $st = $conn->real_escape_string($_POST['status']);
    $where[] = "status LIKE '%$st%'";
}
if (!empty($_POST['requestor'])) {
    $r = $conn->real_escape_string($_POST['requestor']);
    $where[] = "requestor_name LIKE '%$r%'";
}
if (!empty($_POST['item'])) {
    $i = $conn->real_escape_string($_POST['item']);
    $where[] = "item_name LIKE '%$i%'";
}
if (!empty($_POST['from'])) {
    $f = $conn->real_escape_string($_POST['from']);
    $where[] = "DATE(order_date) >= '$f'";
}
if (!empty($_POST['to'])) {
    $t = $conn->real_escape_string($_POST['to']);
    $where[] = "DATE(order_date) <= '$t'";
}

$whereSQL = $where ? "WHERE " . implode(" AND ", $where) : "";

// count total rows (for pagination)
$countSql = "SELECT COUNT(*) AS total FROM orders $whereSQL";
$countRes = $conn->query($countSql);
$totalRows = $countRes ? (int)$countRes->fetch_assoc()['total'] : 0;
$totalPages = $totalRows > 0 ? ceil($totalRows / $limit) : 1;

// fetch page data
$sql = "
    SELECT 
        order_id,
        requestor_name,
        department,
        item_name,
        qty,
        unit,
        order_date,
        expected_date,
        status,
        processed_by,
        created_at
    FROM orders
    $whereSQL
    ORDER BY created_at DESC
    LIMIT $limit OFFSET $offset
";
$res = $conn->query($sql);

// build table
echo "
<table class='table'>
  <thead>
    <tr>
      <th class='sortable'>Order ID</th>
      <th class='sortable'>Requestor</th>
      <th class='sortable'>Department</th>
      <th class='sortable'>Item</th>
      <th class='sortable'>Qty</th>
      <th class='sortable'>Unit</th>
      <th class='sortable'>Order Date</th>
      <th class='sortable'>Expected</th>
      <th class='sortable'>Status</th>
      <th class='sortable'>Processed By</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
";

if (!$res || $res->num_rows === 0) {
    echo "<tr><td colspan='11'>No orders found.</td></tr>";
} else {
    while ($row = $res->fetch_assoc()) {

        $oid   = (int)$row['order_id'];
        $req   = htmlspecialchars($row['requestor_name'] ?? '');
        $dept  = htmlspecialchars($row['department'] ?? '');
        $item  = htmlspecialchars($row['item_name'] ?? '');
        $qty   = htmlspecialchars($row['qty'] ?? '');
        $unit  = htmlspecialchars($row['unit'] ?? '');
        $odate = htmlspecialchars($row['order_date'] ?? '');
        $exp   = htmlspecialchars($row['expected_date'] ?? '');
        $status= htmlspecialchars($row['status'] ?? '');
        $proc  = htmlspecialchars($row['processed_by'] ?? '');

        // Check if the item exists in the inventory table and if the quantity > 0
        $invQuery = $conn->query("
            SELECT * FROM inventory 
            WHERE name='$item' 
            AND (department='$dept' OR department IS NULL OR department = '')
            LIMIT 1
        ");
        
        // Check if inventory quantity is 0 for "In House" orders and revert status
        if ($status == 'In House' && $invQuery && $invQuery->num_rows > 0) {
            $invRow = $invQuery->fetch_assoc();
            if ($invRow['quantity'] == 0) {
                // If the quantity is 0, revert status back to 'Pending'
                $conn->query("UPDATE orders SET status = 'Pending' WHERE order_id = $oid");
            }
        }

        // If the quantity is 0, delete the order from the orders table
        if ($qty == 0) {
            $conn->query("DELETE FROM orders WHERE order_id = $oid");
        }

        // details html for optional modal (View button)
        $detailsHtml = "
            <strong>Order ID:</strong> {$oid}<br>
            <strong>Requestor:</strong> {$req}<br>
            <strong>Department:</strong> {$dept}<br>
            <strong>Item:</strong> {$item}<br>
            <strong>Qty:</strong> {$qty} {$unit}<br>
            <strong>Order Date:</strong> {$odate}<br>
            <strong>Expected Date:</strong> {$exp}<br>
            <strong>Status:</strong> {$status}<br>
            <strong>Processed By:</strong> {$proc}
        ";
        $detailsAttr = htmlspecialchars($detailsHtml, ENT_QUOTES);

        echo "
        <tr>
          <td>{$oid}</td>
          <td>{$req}</td>
          <td>{$dept}</td>
          <td>{$item}</td>
          <td>{$qty}</td>
          <td>{$unit}</td>
          <td>{$odate}</td>
          <td>{$exp}</td>
          <td>
            <select onchange=\"updateStatus({$oid}, this.value)\">
              <option ".($status=='Pending'?'selected':'').">Pending</option>
              <option ".($status=='In House'?'selected':'').">In House</option>
              <option ".($status=='Approved'?'selected':'').">Approved</option>
              <option ".($status=='Rejected'?'selected':'').">Rejected</option>
              <option ".($status=='Delivered'?'selected':'').">Delivered</option>
            </select>
          </td>
          <td>{$proc}</td>
          <td>
            <button type='button' class='view' 
                    onclick=\"goIssuance({$oid})\">Issuance</button>
            <button type='button' class='delete' 
                    onclick=\"deleteOrder({$oid})\">Delete</button>
            <button type='button' class='view-details'
                    data-details=\"{$detailsAttr}\">
              View
            </button>
          </td>
        </tr>
        ";
    }
}

echo "</tbody></table>";

// pagination
echo "<div class='pagination'>";

if ($page > 1) {
    echo "<span class='page-link' data-page='" . ($page - 1) . "'>Previous</span>";
}

for ($i = 1; $i <= $totalPages; $i++) {
    $active = ($i === $page) ? "active" : "";
    echo "<span class='page-link {$active}' data-page='{$i}'>{$i}</span>";
}

if ($page < $totalPages) {
    echo "<span class='page-link' data-page='" . ($page + 1) . "'>Next</span>";
}

echo "</div>";
?>
