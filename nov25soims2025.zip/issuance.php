<?php 
session_start();
require_once 'db_connect.php';

// SECURITY: Must be logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['fullname'])) {
    die("Unauthorized access.");
}

$user_id = $_SESSION['user_id'];
$processed_by = $conn->real_escape_string($_SESSION['fullname']);

// Handle success/error messages AFTER redirect
$message = $_SESSION['issuance_message'] ?? "";
$remaining_before = $_SESSION['remaining_before'] ?? "";
$remaining_after  = $_SESSION['remaining_after'] ?? "";

// Clear session messages so they don't repeat
unset($_SESSION['issuance_message']);
unset($_SESSION['remaining_before']);
unset($_SESSION['remaining_after']);

// Get order details
$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$order = $conn->query("SELECT * FROM orders WHERE order_id=$order_id")->fetch_assoc();

if (!$order) {
    die("Order not found.");
}

// ===========================
//     HANDLE POST (SUBMIT)
// ===========================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $order_id = (int)$_POST['order_id'];
    $issued_qty = (int)$_POST['issued_qty'];

    if ($issued_qty < 1) {
        $_SESSION['issuance_message'] = "<p style='color:red;'>Invalid quantity.</p>";
        header("Location: issuance.php?order_id=$order_id");
        exit();
    }

    // Reload order fresh
    $order = $conn->query("SELECT * FROM orders WHERE order_id=$order_id")->fetch_assoc();
    $item_name = $conn->real_escape_string($order['item_name']);
    $department = $conn->real_escape_string($order['department']);

    // Look for inventory (allowing items with no department)
    $inv = $conn->query("
        SELECT * FROM inventory 
        WHERE name='$item_name' 
        AND (department='$department' OR department IS NULL OR department = '')
        LIMIT 1
    ");

    if ($inv->num_rows === 0) {
        $_SESSION['issuance_message'] = "<p style='color:red;'>The item is not in house yet or has no department assigned.</p>";
        header("Location: issuance.php?order_id=$order_id");
        exit();
    }

    $invRow = $inv->fetch_assoc();
    $remaining_before = $invRow['quantity'];

    if ($invRow['quantity'] < $issued_qty) {
        $_SESSION['issuance_message'] = "<p style='color:red;'>Not enough stock available.</p>";
        header("Location: issuance.php?order_id=$order_id");
        exit();
    }

    // Calculate new remaining stock
    $remaining_after = $invRow['quantity'] - $issued_qty;

    // Prepare the SQL query for issuance
    $insertQuery = "
        INSERT INTO issuances (
            order_id, item_name, issued_qty, processed_by, issued_at, department, requestor_name
        ) 
        VALUES (?, ?, ?, ?, NOW(), ?, ?)
    ";

    // Prepare statement
    $stmt = $conn->prepare($insertQuery);
    if ($stmt) {
        $stmt->bind_param(
            "isisds", 
            $order_id, 
            $item_name, 
            $issued_qty, 
            $processed_by, 
            $department, 
            $order['requestor_name']
        );

        // Execute the query
        if ($stmt->execute()) {
            // Log activity (optional)
            log_activity(
                $user_id,
                "Issued $issued_qty pcs of $item_name to {$order['requestor_name']} (Department: $department)",
                "Issuance",
                "Success",
                $conn
            );

            // Update inventory
            $updateInventory = $conn->prepare("
                UPDATE inventory 
                SET quantity = quantity - ? 
                WHERE inventory_id = ?
            ");
            $updateInventory->bind_param("ii", $issued_qty, $invRow['inventory_id']);
            $updateInventory->execute();

            // Update order
            $updateOrder = $conn->prepare("
                UPDATE orders 
                SET qty = qty - ? 
                WHERE order_id = ?
            ");
            $updateOrder->bind_param("ii", $issued_qty, $order_id);
            $updateOrder->execute();

            // Store output for the next GET (so refresh won't re-submit)
            $_SESSION['issuance_message'] = "<p style='color:green;'>Issued successfully.</p>";
            $_SESSION['remaining_before'] = $remaining_before;
            $_SESSION['remaining_after']  = $remaining_after;
        } else {
            $_SESSION['issuance_message'] = "<p style='color:red;'>Error executing query: " . $stmt->error . "</p>";
        }

        $stmt->close();
    } else {
        $_SESSION['issuance_message'] = "<p style='color:red;'>Error preparing query: " . $conn->error . "</p>";
    }

    // REDIRECT so refresh does NOT re-submit
    header("Location: issuance.php?order_id=$order_id");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Issuance</title>
  <style>
    body { font-family: Arial; background: #f5f6fa; }
    form { background: #fff; max-width: 600px; margin: 50px auto; padding: 25px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,.1); }
    input { width: 100%; padding: 8px; margin: 8px 0; border-radius: 5px; border: 1px solid #ccc; }
    button { padding: 15px 20px; background: #007bff; color: white; align-items: center; border: none; border-radius: 5px; cursor: pointer; }
    .info-box { padding: 10px; background: #e9ecef; border-radius: 5px; margin-bottom: 10px; }
  </style>
</head>
<body>

  <form method="POST">
    <h2>Issue Item</h2>

    <?= $message ?>

    <?php if ($remaining_before !== ""): ?>
      <div class="info-box">
        <strong>Stock Before:</strong> <?= $remaining_before ?><br>
        <strong>Stock After:</strong> <?= $remaining_after ?>
      </div>
    <?php endif; ?>

    <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">

    <label>Requestor:</label>
    <input value="<?= htmlspecialchars($order['requestor_name']) ?>" readonly>

    <label>Department:</label>
    <input value="<?= htmlspecialchars($order['department']) ?>" readonly>

    <label>Item:</label>
    <input value="<?= htmlspecialchars($order['item_name']) ?>" readonly>

    <label>Quantity Ordered:</label>
    <input value="<?= htmlspecialchars($order['qty']) ?>" readonly>

    <label>Quantity to Issue:</label>
    <input name="issued_qty" type="number" min="1" max="<?= $order['qty'] ?>" required>

    <label>Processed By:</label>
    <input value="<?= htmlspecialchars($processed_by) ?>" readonly>

    <a href="order_management.php"
   style="
      display:inline-block;
      margin-top:10px;
      padding:5px 10px;
      background:#6c757d;
      color:white;
      border-radius:5px;
      text-decoration:none;
   ">
   ⬅ Back
</a>
<button type="submit">Issue Now</button>

  </form>

</body>
</html>
